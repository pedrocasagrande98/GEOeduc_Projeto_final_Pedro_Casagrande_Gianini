# Projeto de Análise de Risco de Inundação

Este projeto automatiza a análise de risco de inundação para uma área de interesse (ROI) definida, utilizando dados de SRTM, solos e OpenStreetMap (OSM). O pipeline completo realiza desde o download dos dados até a geração de estatísticas de impacto.

## Funcionalidades

- Download automatizado de dados geoespaciais (SRTM, Solos) via Google Earth Engine.
- Processamento hidrológico completo com PySheds para delinear a bacia hidrográfica.
- Cálculo do modelo HAND (Height Above Nearest Drainage) para estimar a mancha de inundação.
- Análise de vulnerabilidade baseada no tipo de solo, aplicando buffers proporcionais.
- Download de dados de edificações e infraestrutura do OpenStreetMap (OSM) na área de inundação.
- Geração de estatísticas de impacto e relatórios em formato GeoJSON e JSON.
- Tratamento de erros robusto e logging completo de todas as etapas.

## Instalação

1.  Clone este repositório:
    ```bash
    git clone <URL_DO_REPOSITORIO>
    cd 4_versao_automatica
    ```

2.  Crie e ative um ambiente virtual:
    ```bash
    python -m venv venv
    source venv/bin/activate  # No Windows: venv\Scripts\activate
    ```

3.  Instale as dependências:
    ```bash
    pip install -r requirements.txt
    ```

4.  Autentique-se no Google Earth Engine (será solicitado na primeira execução que necessitar):
    ```bash
    earthengine authenticate
    ```

## Como Usar

1.  **Configure os parâmetros no arquivo `config.py`**.
2.  Execute o pipeline principal:
    ```bash
    python main.py
    ```
3.  Os resultados e o arquivo de log (`pipeline.log`) serão salvos no diretório `resultados_finais`.

## Configuração

Antes de executar o script, é essencial ajustar os parâmetros no arquivo `config.py` para adequá-lo à sua área de estudo e análise:

-   `ROI_LOCAL_PATH`: Caminho para o arquivo GeoJSON que define a sua Região de Interesse (ROI) para o download inicial dos dados.
-   `PONTO_EXUTORIO`: Coordenadas (longitude, latitude) do ponto de saída (exutório) da bacia hidrográfica que você deseja analisar.
-   `STREAM_THRESHOLD`: Limiar de acumulação de fluxo para definir o que é considerado um rio.
-   `CHANNEL_DEPTH`: Profundidade estimada do canal do rio (em metros), utilizada no cálculo do HAND.
-   `PERCENTAGE_MAPPING`: Mapeamento que define a porcentagem de buffer a ser aplicada na mancha de inundação com base no tipo de solo.