
import os

# =========================================================================
# 0. CONFIGURAÇÃO GERAL
# =========================================================================

# --- Entradas Principais ---
# Use um GeoJSON para definir a área geral de interesse para o download inicial.
ROI_LOCAL_PATH = os.path.join('data', 'input', 'inundacao_segmentada_por_solo.geojson')

# Coordenadas (lon, lat) para o ponto de saída da bacia.
PONTO_EXUTORIO = (-44.118627, -20.316243)

# --- Parâmetros do Modelo ---
STREAM_THRESHOLD = 1000  # Área de acumulação para definir um rio
CHANNEL_DEPTH = 10.0     # Profundidade do canal em metros para o modelo HAND

# Mapeamento para análise de solo (valor_solo: porcentagem_buffer)
PERCENTAGE_MAPPING = {
    1.0: -40.0, 2.0: -20.0, 3.0: 0.0,
    4.0: 5.0,   5.0: 20.0,  6.0: 35.0
}

# --- Estrutura de Diretórios de Saída ---
OUTPUT_DIR = 'resultados_finais'
SRTM_OUTPUT_FOLDER = os.path.join(OUTPUT_DIR, '0_downloads', 'srtm')
AD_SOLO_OUTPUT_FOLDER = os.path.join(OUTPUT_DIR, '0_downloads', 'ad_solo')
HIDRO_OUTPUT_DIR = os.path.join(OUTPUT_DIR, '1_processamento_hidrologico')
OSM_OUTPUT_DIR = os.path.join(OUTPUT_DIR, '2_dados_osm')
SOIL_ANALYSIS_OUTPUT_DIR = os.path.join(OUTPUT_DIR, '3_analise_solo')
IMPACT_STATS_OUTPUT_DIR = os.path.join(OUTPUT_DIR, '4_estatisticas_impacto')
BASIN_STATS_OUTPUT_DIR = os.path.join(OUTPUT_DIR, '5_estatisticas_bacia')
