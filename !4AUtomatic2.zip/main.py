
import os
import json
import config
import logging
import sys
from src.data.download import download_srtm_gee, download_ad_solos_gee
from src.processing.hydrology import (
    processar_mde_pysheds,
    delinear_bacia,
    calcular_slope_aspect_twi,
    calcular_hand
)
from src.processing.osm import baixar_dados_osmnx
from src.processing.soil_analysis import segmentar_inundacao_por_solo, aplicar_buffer_proporcional
from src.analysis.statistics import calcular_estatisticas_impacto_osm
from src.analysis.basin_statistics import analyze_basin_statistics

# Garante que o diretório de saída principal exista antes de configurar o logging de arquivo
os.makedirs(config.OUTPUT_DIR, exist_ok=True)

# Configuração do Logger
log_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Handler para salvar em arquivo
file_handler = logging.FileHandler(os.path.join(config.OUTPUT_DIR, 'pipeline.log'))
file_handler.setFormatter(log_formatter)
logger.addHandler(file_handler)

# Handler para exibir no console
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setFormatter(log_formatter)
logger.addHandler(console_handler)

def main():
    """
    Orquestra o fluxo completo de análise de risco de inundação.
    """
    # --- 1. PREPARAÇÃO E DOWNLOAD ---
    logging.info("--- Etapa 1: Preparação e Download de Dados ---")
    # Cria toda a estrutura de pastas
    for path in [config.SRTM_OUTPUT_FOLDER, config.AD_SOLO_OUTPUT_FOLDER, config.HIDRO_OUTPUT_DIR, config.OSM_OUTPUT_DIR,
                 config.SOIL_ANALYSIS_OUTPUT_DIR, config.IMPACT_STATS_OUTPUT_DIR, config.BASIN_STATS_OUTPUT_DIR]:
        os.makedirs(path, exist_ok=True)

    srtm_path = download_srtm_gee(config.ROI_LOCAL_PATH, config.SRTM_OUTPUT_FOLDER)
    ad_solo_path = download_ad_solos_gee(config.ROI_LOCAL_PATH, config.AD_SOLO_OUTPUT_FOLDER)

    if not srtm_path or not ad_solo_path:
        logging.error("Falha no download dos dados primários. Abortando.")
        return

    # --- 2. PROCESSAMENTO HIDROLÓGICO E DELINEAÇÃO DA BACIA ---
    logging.info("--- Etapa 2: Processamento Hidrológico e Delineação da Bacia ---")
    fdir_path, acc_path, grid_full, fdir, acc, dirmap, inflated_dem = processar_mde_pysheds(srtm_path, config.HIDRO_OUTPUT_DIR)
    if not grid_full:
        logging.error("Falha no processamento MDE inicial. Abortando.")
        return

    bacia_path, grid_clipped = delinear_bacia(grid_full, fdir, acc, dirmap, config.PONTO_EXUTORIO, config.STREAM_THRESHOLD, config.HIDRO_OUTPUT_DIR)
    if not bacia_path:
        logging.error("Falha ao delinear a bacia. Abortando.")
        return

    # --- 3. CÁLCULOS DENTRO DA BACIA ---
    logging.info("--- Etapa 3: Cálculos de Hidrologia e Inundação na Bacia ---")
    slope_path, aspect_path, twi_path = calcular_slope_aspect_twi(grid_clipped, inflated_dem, acc, config.HIDRO_OUTPUT_DIR)
    inundacao_raster_path, inundacao_vetor_path = calcular_hand(grid_clipped, fdir, inflated_dem, acc, config.STREAM_THRESHOLD, config.CHANNEL_DEPTH, config.HIDRO_OUTPUT_DIR)

    if not inundacao_vetor_path:
        logging.error("Falha ao calcular a mancha de inundação. Abortando.")
        return

    # --- 4. DOWNLOAD OSM E ANÁLISE DE SOLO ---
    logging.info("--- Etapa 4: Download de Dados OSM e Análise de Solo ---")
    osm_polygons_path, osm_lines_path, osm_points_path = baixar_dados_osmnx(inundacao_vetor_path, config.OSM_OUTPUT_DIR)
    if not osm_polygons_path:
        logging.warning("Não foi possível baixar dados de polígonos do OSM.")

    inundacao_segmentada_path = segmentar_inundacao_por_solo(inundacao_vetor_path, ad_solo_path, os.path.join(config.SOIL_ANALYSIS_OUTPUT_DIR, 'inundacao_segmentada.geojson'))
    inundacao_com_buffer_path = aplicar_buffer_proporcional(inundacao_segmentada_path, 'valor_solo', config.PERCENTAGE_MAPPING, config.SOIL_ANALYSIS_OUTPUT_DIR, 'inundacao_final_com_buffer.geojson')

    if not inundacao_com_buffer_path:
        logging.error("Falha na análise de solo e buffer. Abortando.")
        return

    # --- 5. ESTATÍSTICAS DE IMPACTO NA MANCHA DE INUNDAÇÃO ---
    logging.info("--- Etapa 5: Cálculo de Estatísticas de Impacto na Inundação ---")
    stats_path = calcular_estatisticas_impacto_osm(inundacao_com_buffer_path, osm_polygons_path, os.path.join(config.IMPACT_STATS_OUTPUT_DIR, 'inundacao_final_com_stats.geojson'))
    if stats_path:
        logging.info(f"Estatísticas de impacto salvas em: {stats_path}")

    # --- 6. ANÁLISE FINAL SOBRE A BACIA HIDROGRÁFICA ---
    logging.info("--- Etapa 6: Análise Estatística Final Sobre a Bacia Hidrográfica ---")
    
    # Lista de todos os rasters e vetores gerados para análise
    rasters_to_analyze = [srtm_path, ad_solo_path, fdir_path, acc_path, slope_path, aspect_path, twi_path, inundacao_raster_path]
    vectors_to_analyze = [inundacao_vetor_path, inundacao_com_buffer_path, osm_polygons_path, osm_lines_path, osm_points_path]

    basin_stats_results = analyze_basin_statistics(
        bacia_path=bacia_path,
        raster_files=[p for p in rasters_to_analyze if p is not None],
        vector_files=[p for p in vectors_to_analyze if p is not None],
        output_dir=config.BASIN_STATS_OUTPUT_DIR
    )

    if basin_stats_results:
        stats_summary_path = os.path.join(config.BASIN_STATS_OUTPUT_DIR, 'summary_basin_statistics.json')
        with open(stats_summary_path, 'w') as f:
            json.dump(basin_stats_results, f, indent=4)
        logging.info(f"Relatório de estatísticas da bacia salvo em: {stats_summary_path}")

    logging.info("--- Fluxo de Trabalho Concluído com Sucesso! ---")

if __name__ == '__main__':
    main()
