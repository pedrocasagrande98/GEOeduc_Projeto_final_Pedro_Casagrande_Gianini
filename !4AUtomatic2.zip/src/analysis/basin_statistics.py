
import geopandas as gpd
import rasterio
import rasterio.mask
import numpy as np
import os

def analyze_basin_statistics(
    bacia_path,
    raster_files, # Lista de caminhos para arquivos raster
    vector_files, # Lista de caminhos para arquivos vetoriais
    output_dir
):
    """
    Clips all data to the basin boundary and extracts statistics.

    Args:
        bacia_path (str): Path to the basin GeoJSON file.
        raster_files (list): A list of paths to raster files to be clipped.
        vector_files (list): A list of paths to vector files to be intersected.
        output_dir (str): Directory to save the clipped files and statistics.

    Returns:
        dict: A dictionary containing the extracted statistics.
    """
    stats = {
        'rasters': {},
        'vectors': {}
    }

    try:
        # Criar subdiretórios para saídas recortadas
        clipped_rasters_dir = os.path.join(output_dir, 'clipped_rasters')
        clipped_vectors_dir = os.path.join(output_dir, 'clipped_vectors')
        os.makedirs(clipped_rasters_dir, exist_ok=True)
        os.makedirs(clipped_vectors_dir, exist_ok=True)

        # Carregar a bacia
        bacia_gdf = gpd.read_file(bacia_path)
        if bacia_gdf.empty:
            raise ValueError("Basin GeoDataFrame is empty.")
        bacia_geom = bacia_gdf.geometry.unary_union

        # --- 1. Processar Rasters ---
        print("--- Clipping Rasters to Basin ---")
        for raster_path in raster_files:
            if not os.path.exists(raster_path):
                print(f"Warning: Raster file not found, skipping: {raster_path}")
                continue

            try:
                with rasterio.open(raster_path) as src:
                    # Reprojetar bacia se necessário
                    if bacia_gdf.crs != src.crs:
                        bacia_gdf_proj = bacia_gdf.to_crs(src.crs)
                    else:
                        bacia_gdf_proj = bacia_gdf

                    out_image, out_transform = rasterio.mask.mask(
                        src,
                        bacia_gdf_proj.geometry,
                        crop=True,
                        nodata=src.nodata
                    )
                    out_meta = src.meta.copy()

                    out_meta.update({
                        "driver": "GTiff",
                        "height": out_image.shape[1],
                        "width": out_image.shape[2],
                        "transform": out_transform
                    })

                    # Salvar raster recortado
                    clipped_raster_name = f"{os.path.splitext(os.path.basename(raster_path))[0]}_clipped.tif"
                    clipped_raster_path = os.path.join(clipped_rasters_dir, clipped_raster_name)
                    with rasterio.open(clipped_raster_path, "w", **out_meta) as dest:
                        dest.write(out_image)

                    # Calcular estatísticas (min/max)
                    # Ignorar valores nodata no cálculo
                    valid_data = out_image[out_image != src.nodata]
                    if valid_data.size > 0:
                        min_val = float(np.min(valid_data))
                        max_val = float(np.max(valid_data))
                    else:
                        min_val, max_val = None, None

                    stats['rasters'][os.path.basename(raster_path)] = {
                        'clipped_path': clipped_raster_path,
                        'min': min_val,
                        'max': max_val
                    }
                    print(f"Clipped: {os.path.basename(raster_path)} -> Min: {min_val}, Max: {max_val}")

            except Exception as e:
                print(f"Error processing raster {os.path.basename(raster_path)}: {e}")

        # --- 2. Processar Vetores ---
        print("\n--- Intersecting Vectors with Basin ---")
        for vector_path in vector_files:
            if not os.path.exists(vector_path):
                print(f"Warning: Vector file not found, skipping: {vector_path}")
                continue

            try:
                vector_gdf = gpd.read_file(vector_path)
                if vector_gdf.empty:
                    continue

                # Reprojetar bacia se necessário
                if vector_gdf.crs != bacia_gdf.crs:
                    bacia_gdf_proj = bacia_gdf.to_crs(vector_gdf.crs)
                else:
                    bacia_gdf_proj = bacia_gdf

                # Interseção
                intersected_gdf = gpd.overlay(vector_gdf, bacia_gdf_proj, how='intersection')

                if intersected_gdf.empty:
                    print(f"No intersection found for: {os.path.basename(vector_path)}")
                    continue

                # Salvar vetor intersectado
                clipped_vector_name = f"{os.path.splitext(os.path.basename(vector_path))[0]}_intersected.geojson"
                clipped_vector_path = os.path.join(clipped_vectors_dir, clipped_vector_name)
                intersected_gdf.to_file(clipped_vector_path, driver='GeoJSON')

                # Extrair estatísticas de colunas interessantes
                vector_stats = {'clipped_path': clipped_vector_path, 'count': len(intersected_gdf)}
                if 'valor_solo' in intersected_gdf.columns:
                    vector_stats['soil_value_counts'] = intersected_gdf['valor_solo'].value_counts().to_dict()
                if 'strahler_order' in intersected_gdf.columns:
                    vector_stats['strahler_order_counts'] = intersected_gdf['strahler_order'].value_counts().to_dict()
                if 'building' in intersected_gdf.columns:
                    vector_stats['building_counts'] = intersected_gdf['building'].value_counts().to_dict()

                stats['vectors'][os.path.basename(vector_path)] = vector_stats
                print(f"Intersected: {os.path.basename(vector_path)} -> Features: {len(intersected_gdf)}")

            except Exception as e:
                print(f"Error processing vector {os.path.basename(vector_path)}: {e}")

        return stats

    except Exception as e:
        print(f"An error occurred in basin statistics analysis: {e}")
        return None
