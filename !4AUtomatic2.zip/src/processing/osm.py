
import osmnx as ox
import geopandas as gpd
from shapely.geometry import box
from pyproj import CRS
import os

def baixar_dados_osmnx(inundacao_geojson_path, output_dir):
    """
    Downloads and filters OSM data for a given flood area.

    Args:
        inundacao_geojson_path (str): Path to the flood GeoJSON file.
        output_dir (str): Directory to save the OSM data.

    Returns:
        tuple: Paths to the saved OSM polygons, lines, and points files.
    """
    try:
        src_gdf = gpd.read_file(inundacao_geojson_path)
        flood_crs = src_gdf.crs
        flood_bounds = src_gdf.total_bounds
        aoi_bbox_native = box(*flood_bounds)
        aoi_gdf_native = gpd.GeoDataFrame([1], geometry=[aoi_bbox_native], crs=flood_crs)

        target_crs_epsg = 4326
        if flood_crs.to_epsg() != target_crs_epsg:
            aoi_gdf_4326 = aoi_gdf_native.to_crs(epsg=target_crs_epsg)
        else:
            aoi_gdf_4326 = aoi_gdf_native

        aoi_polygon_4326 = aoi_gdf_4326.geometry.iloc[0]

        tags_to_fetch = {
            'building': True, 'building:part': True, 'roof': True, 'man_made': True,
            'highway': True, 'railway': True, 'aeroway': True, 'public_transport': True,
            'natural': True,
            'waterway': True,
            'landuse': True,
            'amenity': True, 'shop': True, 'office': True, 'leisure': True, 'tourism': True, 'historic': True,
            'power': True, 'telecom': True, 'pipeline': True,
            'boundary': True,
            'wall': ['flood_wall', 'retaining_wall'], 'barrier': True, 'flood_asset': True,
            'flood_prone': ['yes'],
            'emergency': True,
            'place': True
        }

        osm_features_gdf = ox.features_from_polygon(aoi_polygon_4326, tags_to_fetch)

        if osm_features_gdf.crs is None:
            osm_features_gdf.crs = CRS.from_epsg(target_crs_epsg)

        keys_to_exclude = ['boundary', 'place']
        exclusion_mask = False
        for key in keys_to_exclude:
            if key in osm_features_gdf.columns:
                exclusion_mask |= osm_features_gdf[key].notna()
        osm_features_gdf = osm_features_gdf[~exclusion_mask].copy()

        osm_polygons_path = os.path.join(output_dir, 'osm_polygons.gpkg')
        osm_lines_path = os.path.join(output_dir, 'osm_lines.gpkg')
        osm_points_path = os.path.join(output_dir, 'osm_points.gpkg')

        osm_polygons_gdf = osm_features_gdf[osm_features_gdf.geometry.type.isin(['Polygon', 'MultiPolygon'])].copy()
        if not osm_polygons_gdf.empty:
            osm_polygons_gdf.to_file(osm_polygons_path, driver="GPKG")

        osm_lines_gdf = osm_features_gdf[osm_features_gdf.geometry.type.isin(['LineString', 'MultiLineString'])].copy()
        if not osm_lines_gdf.empty:
            osm_lines_gdf.to_file(osm_lines_path, driver="GPKG")

        osm_points_gdf = osm_features_gdf[osm_features_gdf.geometry.type == 'Point'].copy()
        if not osm_points_gdf.empty:
            osm_points_gdf.to_file(osm_points_path, driver="GPKG")

        return osm_polygons_path, osm_lines_path, osm_points_path

    except Exception as e:
        print(f"Error downloading OSM data: {e}")
        return None, None, None
