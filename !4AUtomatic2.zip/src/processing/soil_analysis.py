
import geopandas as gpd
import rasterio
import rasterio.mask
import rasterio.features
from shapely.geometry import shape
from scipy.optimize import brentq
import os
import pandas as pd

def segmentar_inundacao_por_solo(vector_file, raster_file, output_file):
    """
    Segments a flood vector by soil type.

    Args:
        vector_file (str): Path to the flood vector file.
        raster_file (str): Path to the soil raster file.
        output_file (str): Path to save the segmented flood file.

    Returns:
        str: Path to the segmented flood file.
    """
    try:
        gdf_inundacao = gpd.read_file(vector_file)

        with rasterio.open(raster_file) as src_raster:
            raster_crs = src_raster.crs
            if gdf_inundacao.crs != raster_crs:
                gdf_inundacao = gdf_inundacao.to_crs(raster_crs)

            geoms = [feature["geometry"] for feature in gdf_inundacao.iterfeatures()]
            out_image, out_transform = rasterio.mask.mask(
                src_raster, geoms, crop=True, filled=True, nodata=src_raster.nodata
            )
            nodata_value = src_raster.nodata
            if nodata_value is None:
                nodata_value = -9999
                out_image[out_image == 0] = nodata_value

            image = out_image[0].astype('int32')
            shapes = rasterio.features.shapes(image, transform=out_transform)

            polygons = []
            values = []
            for geom, value in shapes:
                if value != nodata_value:
                    polygons.append(shape(geom))
                    values.append(value)

            gdf_solos = gpd.GeoDataFrame(
                data={'valor_solo': values}, geometry=polygons, crs=raster_crs
            )

            gdf_intersected = gpd.overlay(
                gdf_inundacao, gdf_solos, how='intersection', keep_geom_type=True
            )

            gdf_intersected.to_file(output_file, driver="GeoJSON")

            return output_file

    except Exception as e:
        print(f"Error segmenting flood by soil: {e}")
        return None

def aplicar_buffer_proporcional(gjson_path, ref_col_name, mapping, out_dir, merge_filename):
    """
    Applies a proportional buffer to a GeoJSON file based on a reference column.

    Args:
        gjson_path (str): Path to the GeoJSON file.
        ref_col_name (str): The name of the reference column.
        mapping (dict): A dictionary mapping values to buffer percentages.
        out_dir (str): The output directory.
        merge_filename (str): The name of the merged output file.

    Returns:
        str: The path to the merged output file.
    """
    def find_buffer_distance_for_area(geometry, target_area, search_min, search_max):
        def area_difference(distance):
            return geometry.buffer(distance).area - target_area
        try:
            return brentq(area_difference, a=search_min, b=search_max, xtol=0.01)
        except ValueError as e:
            raise ValueError(f"Scipy brentq failed. {e}")

    def calculate_area_buffers(gdf, metric_crs, percent_change):
        if gdf.empty:
            return gdf.copy(), gdf.copy()

        gdf_proj = gdf.to_crs(metric_crs)
        geoms_plus = []
        geoms_minus = []
        factor_plus = 1.0 + (percent_change / 100.0)
        factor_minus = 1.0 - (percent_change / 100.0)

        for index, row in gdf_proj.iterrows():
            geom = row.geometry
            if geom.is_empty:
                geoms_plus.append(geom)
                geoms_minus.append(geom)
                continue

            area_original_m2 = geom.area
            area_target_plus = area_original_m2 * factor_plus
            area_target_minus = area_original_m2 * factor_minus

            dist_pos = None
            dist_neg = None

            try:
                dist_pos = find_buffer_distance_for_area(geom, area_target_plus, 0.0, 500.0)
            except ValueError:
                pass

            try:
                dist_neg = find_buffer_distance_for_area(geom, area_target_minus, -500.0, 0.0)
            except ValueError:
                pass

            geoms_plus.append(geom.buffer(dist_pos) if dist_pos is not None else geom)
            geoms_minus.append(geom.buffer(dist_neg) if dist_neg is not None else geom)

        gdf_plus = gdf_proj.copy()
        gdf_plus['geometry'] = geoms_plus
        gdf_minus = gdf_proj.copy()
        gdf_minus['geometry'] = geoms_minus

        return gdf_plus, gdf_minus

    try:
        buffered_gdfs = []
        gdf_original = gpd.read_file(gjson_path)
        if ref_col_name not in gdf_original.columns:
            return None

        original_crs = gdf_original.crs if gdf_original.crs else 'EPSG:4326'
        os.makedirs(out_dir, exist_ok=True)

        values_to_process = [val for val in gdf_original[ref_col_name].unique() if val in mapping]

        for col_value in sorted(values_to_process):
            percent = mapping[col_value]
            gdf_filtered = gdf_original[gdf_original[ref_col_name] == col_value].copy()
            gdf_plus_proj, gdf_minus_proj = calculate_area_buffers(gdf_filtered, 'esri:102033', abs(percent))
            is_positive = percent >= 0
            gdf_final_proj = gdf_plus_proj if is_positive else gdf_minus_proj
            gdf_final_crs = gdf_final_proj.to_crs(original_crs)
            buffered_gdfs.append(gdf_final_crs)

        if buffered_gdfs:
            gdf_merged = gpd.GeoDataFrame(pd.concat(buffered_gdfs, ignore_index=True), crs=original_crs)
            final_merge_path = os.path.join(out_dir, merge_filename)
            gdf_merged.to_file(final_merge_path, driver='GeoJSON')
            return final_merge_path
        else:
            return None

    except Exception as e:
        print(f"Error applying proportional buffer: {e}")
        return None
