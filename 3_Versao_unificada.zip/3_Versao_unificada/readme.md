### ARQUIVO 0 = 0_download_srtm_ad_solo.ipynb
    Este arquivo nos permite fazer o donwload do MDE ou AD_SOLO; Ambos serão utilizados no projeto,
    embora temos mais ênfase no arquivo SRTM inciando todos os processamento Hidrológicos e AD_solo
    é utilizado no final;


### ARQUIVO 1 = 1_hand_osmnx.ipynb
    Neste arquivo fazemos o processamento hidrlógico e métricos para delineamento da Bacia Hidrográfica,
    assim como o modelo de inundação vetorizado; E também é aqui que fazemos o donwload dos dados OSMNX

### ARQUIVO 2 = 2_Ad_solo_buffer_proporcional_by_column.ipynb
    Esse arquivo fica responsável por receber a camada de interese vetorial + nossa imagem AD_SOLO,
    fazemos então uma extração por máscara seguida de uma vetorização

### ARQUIVO 3 = 3_Statistics_plot.ipynb
    Nosso último arquivo fica responsável por, receber a camada escolhida de inundacao e a camada
    dos objetos impactados, ambos vetoriais. Tirando estatísticas de quantos tinhamos no início e 
    quantos foram atingidos.
    

### ARQUIVO 4 = open_buildingV3_statistics.ipynb
    Usamos por fim uma camada que é muito difícil de ser exportada, porém muito boa para se obter 
    estatisticas diretamente sobre construções, trazendo um quantitativo um pouco mais proximo da realidaed