# Análise de Risco de Inundação com Refinamento por Tipo de Solo

Este projeto realiza uma análise de risco de inundação, utilizando o modelo HAND para gerar uma mancha de inundação base e refinando-a com base no tipo de solo, aplicando um buffer proporcional.

## Como Instalar

1. Clone o repositório.
2. Crie um ambiente virtual e ative-o.
3. Instale as dependências:

```bash
pip install -r requirements.txt
```

## Como Usar

1. Configure os caminhos de entrada e saída no arquivo `main.py`.
2. Execute o script:

```bash
python main.py
```

## Metodologia

O fluxo de trabalho consiste nas seguintes etapas:

1. **Download de Dados**: Download de dados de MDE (SRTM) e de um raster customizado de "Água Disponível no Solo" (AD_Solos) do Google Earth Engine.
2. **Processamento Hidrológico**: Processamento do MDE para gerar insumos hidrológicos (Direção de Fluxo, Acumulação, TWI, Slope), cálculo do modelo HAND para gerar uma mancha de inundação base e download de dados do OpenStreetMap (OSMnx).
3. **Refinamento pelo Solo**: A mancha de inundação é refinada usando o raster AD_solos para segmentar a mancha e, em seguida, aplicando um buffer proporcional com base na classe de solo.
4. **Análise de Estatísticas**: Cálculo de estatísticas de impacto, cruzando a mancha de inundação final com os polígonos do OSM para quantificar os danos.
