
from src.data.download import download_srtm_gee, download_ad_solos_gee
from src.processing.hydrology import processar_mde_pysheds, calcular_slope_aspect_twi, calcular_hand
from src.processing.osm import baixar_dados_osmnx
from src.processing.soil_analysis import segmentar_inundacao_por_solo, aplicar_buffer_proporcional
from src.analysis.statistics import calcular_estatisticas_impacto_osm
import os

# =========================================================================
# 0. DEFINIÇÕES DE CAMINHO LOCAL E CONFIGURAÇÃO
# =========================================================================

ROI_LOCAL_PATH = r'D:\POS\!FW2_HAND_osmnx_4s_op3n\3_Versao_unificada\bases\inundacao_segmentada_por_solo.geojson'
OUTPUT_DIR = 'resultados'
SRTM_OUTPUT_FOLDER = os.path.join(OUTPUT_DIR, 'srtm')
AD_SOLO_OUTPUT_FOLDER = os.path.join(OUTPUT_DIR, 'ad_solo')
HIDRO_OUTPUT_DIR = os.path.join(OUTPUT_DIR, 'hidrologia')
OSM_OUTPUT_DIR = os.path.join(OUTPUT_DIR, 'osm')
SOIL_ANALYSIS_OUTPUT_DIR = os.path.join(OUTPUT_DIR, 'analise_solo')
STATS_OUTPUT_DIR = os.path.join(OUTPUT_DIR, 'estatisticas')

STREAM_THRESHOLD = 1000
CHANNEL_DEPTH = 10.0

PERCENTAGE_MAPPING = {
    1.0: -40.0,
    2.0: -20.0,
    3.0: 0.0,
    4.0: 5.0,
    5.0: 20.0,
    6.0: 35.0
}

def main():
    """
    Main function to run the entire flood risk analysis workflow.
    """
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    os.makedirs(SRTM_OUTPUT_FOLDER, exist_ok=True)
    os.makedirs(AD_SOLO_OUTPUT_FOLDER, exist_ok=True)
    os.makedirs(HIDRO_OUTPUT_DIR, exist_ok=True)
    os.makedirs(OSM_OUTPUT_DIR, exist_ok=True)
    os.makedirs(SOIL_ANALYSIS_OUTPUT_DIR, exist_ok=True)
    os.makedirs(STATS_OUTPUT_DIR, exist_ok=True)

    # 1. Download data
    print("--- 1. Downloading data ---")
    srtm_path = download_srtm_gee(ROI_LOCAL_PATH, SRTM_OUTPUT_FOLDER)
    ad_solo_path = download_ad_solos_gee(ROI_LOCAL_PATH, AD_SOLO_OUTPUT_FOLDER)

    if not srtm_path or not ad_solo_path:
        print("Error downloading data. Exiting.")
        return

    # 2. Process hydrology
    print("--- 2. Processing hydrology ---")
    fdir_path, acc_path, grid, fdir, acc, dirmap, inflated_dem = processar_mde_pysheds(srtm_path, HIDRO_OUTPUT_DIR)
    calcular_slope_aspect_twi(grid, inflated_dem, acc, HIDRO_OUTPUT_DIR)
    inundacao_path = calcular_hand(grid, fdir, inflated_dem, acc, STREAM_THRESHOLD, CHANNEL_DEPTH, HIDRO_OUTPUT_DIR)

    if not inundacao_path:
        print("Error processing hydrology. Exiting.")
        return

    # 3. Download OSM data
    print("--- 3. Downloading OSM data ---")
    osm_polygons_path, _, _ = baixar_dados_osmnx(inundacao_path, OSM_OUTPUT_DIR)

    if not osm_polygons_path:
        print("Error downloading OSM data. Exiting.")
        return

    # 4. Soil analysis
    print("--- 4. Performing soil analysis ---")
    inundacao_segmentada_path = segmentar_inundacao_por_solo(inundacao_path, ad_solo_path, os.path.join(SOIL_ANALYSIS_OUTPUT_DIR, 'inundacao_segmentada.geojson'))
    inundacao_com_buffer_path = aplicar_buffer_proporcional(inundacao_segmentada_path, 'valor_solo', PERCENTAGE_MAPPING, SOIL_ANALYSIS_OUTPUT_DIR, 'inundacao_com_buffer.geojson')

    if not inundacao_com_buffer_path:
        print("Error in soil analysis. Exiting.")
        return

    # 5. Statistics
    print("--- 5. Calculating statistics ---")
    calcular_estatisticas_impacto_osm(inundacao_com_buffer_path, osm_polygons_path, os.path.join(STATS_OUTPUT_DIR, 'inundacao_com_stats.geojson'))

    print("--- Workflow finished successfully! ---")

if __name__ == '__main__':
    main()
