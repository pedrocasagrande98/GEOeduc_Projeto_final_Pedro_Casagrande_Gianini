
import os
import geopandas as gpd
from pyproj import CRS

def calcular_estatisticas_impacto_osm(inundacao_vetor_path, osm_polygons_path, output_inundacao_stats_path):
    """
    Calculates impact statistics by intersecting flood data with OSM polygons.

    Args:
        inundacao_vetor_path (str): Path to the flood vector file.
        osm_polygons_path (str): Path to the OSM polygons GeoPackage.
        output_inundacao_stats_path (str): Path to save the flood vector with stats.

    Returns:
        str: Path to the saved flood vector with stats.
    """
    try:
        if not os.path.exists(inundacao_vetor_path):
            return None

        flood_analysis_gdf = gpd.read_file(inundacao_vetor_path)
        if len(flood_analysis_gdf) > 1:
            flood_analysis_gdf['temp_id'] = 1
            flood_analysis_gdf = flood_analysis_gdf.dissolve(by='temp_id')

        if not os.path.exists(osm_polygons_path):
            return None

        osm_polygons_gdf_input = gpd.read_file(osm_polygons_path)
        target_crs = flood_analysis_gdf.crs if not flood_analysis_gdf.empty and flood_analysis_gdf.crs else osm_polygons_gdf_input.crs

        if osm_polygons_gdf_input.empty:
            osm_polygons_gdf = gpd.GeoDataFrame(geometry=[], crs=target_crs)
        elif osm_polygons_gdf_input.crs != target_crs and target_crs is not None:
            osm_polygons_gdf = osm_polygons_gdf_input.to_crs(target_crs)
        else:
            osm_polygons_gdf = osm_polygons_gdf_input

        if 'natural' in osm_polygons_gdf.columns:
            osm_polygons_gdf = osm_polygons_gdf[osm_polygons_gdf['natural'].fillna('').astype(str).str.lower() != 'water']
        if 'water' in osm_polygons_gdf.columns:
            osm_polygons_gdf = osm_polygons_gdf[osm_polygons_gdf['water'].isna()]

        if not osm_polygons_gdf.empty and not flood_analysis_gdf.empty:
            if osm_polygons_gdf.crs != flood_analysis_gdf.crs:
                osm_polygons_gdf = osm_polygons_gdf.to_crs(flood_analysis_gdf.crs)

            affected_sjoin = gpd.sjoin(osm_polygons_gdf, flood_analysis_gdf, how='inner', predicate='intersects')
            affected_polygons_gdf = affected_sjoin[~affected_sjoin.index.duplicated(keep='first')]
        else:
            affected_polygons_gdf = gpd.GeoDataFrame(geometry=[], crs=target_crs if target_crs is not None else CRS.from_epsg(4326))

        total_polygons_aoi = len(osm_polygons_gdf)
        stats_impact_total = len(affected_polygons_gdf)
        stats_impact_buildings = 0
        if 'building' in affected_polygons_gdf.columns:
            stats_impact_buildings = len(affected_polygons_gdf[affected_polygons_gdf['building'].notna() & (affected_polygons_gdf['building'].astype(str).str.lower() != 'no')])

        stats_impact_infra_critica = 0
        if 'amenity' in affected_polygons_gdf.columns:
            critical_amenities = ['hospital', 'school']
            stats_impact_infra_critica = len(affected_polygons_gdf[affected_polygons_gdf['amenity'].isin(critical_amenities)])

        stats_impact_comercio = 0
        if 'shop' in affected_polygons_gdf.columns:
            stats_impact_comercio = len(affected_polygons_gdf[affected_polygons_gdf['shop'].notna()])

        if total_polygons_aoi > 0:
            saved_percent_affected = (stats_impact_total / total_polygons_aoi) * 100
        else:
            saved_percent_affected = 0.0

        if not flood_analysis_gdf.empty and len(flood_analysis_gdf) >= 1:
            first_index = flood_analysis_gdf.index[0]
            flood_analysis_gdf.loc[first_index, 'osm_total_aoi'] = total_polygons_aoi
            flood_analysis_gdf.loc[first_index, 'impact_total'] = stats_impact_total
            flood_analysis_gdf.loc[first_index, 'impact_perc_total'] = round(saved_percent_affected, 2)
            flood_analysis_gdf.loc[first_index, 'impact_buildings'] = stats_impact_buildings
            flood_analysis_gdf.loc[first_index, 'impact_infra_critica'] = stats_impact_infra_critica
            flood_analysis_gdf.loc[first_index, 'impact_comercio'] = stats_impact_comercio

            flood_analysis_gdf.to_file(output_inundacao_stats_path, driver='GeoJSON')
            return output_inundacao_stats_path
        else:
            return None

    except Exception as e:
        print(f"Error calculating impact statistics: {e}")
        return None
