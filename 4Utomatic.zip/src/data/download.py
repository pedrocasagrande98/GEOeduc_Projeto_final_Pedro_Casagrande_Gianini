
import ee
import os
import sys
import geopandas as gpd
import urllib.request

def download_srtm_gee(roi_path, output_folder, scale_meters=30):
    """
    Downloads SRTM elevation data from Google Earth Engine.

    Args:
        roi_path (str): Path to the region of interest (ROI) GeoJSON file.
        output_folder (str): Folder to save the downloaded SRTM data.
        scale_meters (int): The scale in meters to download the data.

    Returns:
        str: The path to the downloaded SRTM file.
    """
    try:
        os.makedirs(output_folder, exist_ok=True)
        ee.Initialize()

        gdf_roi = gpd.read_file(roi_path)
        roi_geojson = gdf_roi.geometry.__geo_interface__
        ee_features = [ee.Feature(ee.Geometry(feature['geometry'])) for feature in roi_geojson['features']]
        roi_feature_collection = ee.FeatureCollection(ee_features)
        roi_geometry = roi_feature_collection.geometry()

        srtm_image = ee.Image("USGS/SRTMGL1_003")
        srtm_elevation = srtm_image.select('elevation')

        url = srtm_elevation.getDownloadURL({
            'scale': scale_meters,
            'crs': 'EPSG:4326',
            'region': roi_geometry.bounds().getInfo()['coordinates'],
            'format': 'GeoTIFF'
        })

        output_filename = "srtm_elevation.tif"
        local_filepath = os.path.join(output_folder, output_filename)
        urllib.request.urlretrieve(url, local_filepath)

        return local_filepath

    except Exception as e:
        print(f"Error downloading SRTM data: {e}")
        return None

def download_ad_solos_gee(roi_path, output_folder):
    """
    Downloads custom soil data from Google Earth Engine.

    Args:
        roi_path (str): Path to the region of interest (ROI) GeoJSON file.
        output_folder (str): Folder to save the downloaded soil data.

    Returns:
        str: The path to the downloaded soil data file.
    """
    try:
        os.makedirs(output_folder, exist_ok=True)
        ee.Initialize()

        gdf_roi = gpd.read_file(roi_path)
        roi_geojson = gdf_roi.geometry.__geo_interface__
        ee_features = [ee.Feature(ee.Geometry(feature['geometry'])) for feature in roi_geojson['features']]
        roi_feature_collection = ee.FeatureCollection(ee_features)
        roi_geometry = roi_feature_collection.geometry()

        solos_image = ee.Image("projects/ee-phccasagrande20/assets/AD_Solos_30m")
        native_projection = solos_image.projection()
        scale_meters = native_projection.nominalScale().getInfo()

        url = solos_image.getDownloadURL({
            'scale': scale_meters,
            'crs': 'EPSG:4326',
            'region': roi_geometry.bounds().getInfo()['coordinates'],
            'format': 'GeoTIFF'
        })

        output_filename = "AD_solos.tif"
        local_filepath = os.path.join(output_folder, output_filename)
        urllib.request.urlretrieve(url, local_filepath)

        return local_filepath

    except Exception as e:
        print(f"Error downloading AD solos data: {e}")
        return None
