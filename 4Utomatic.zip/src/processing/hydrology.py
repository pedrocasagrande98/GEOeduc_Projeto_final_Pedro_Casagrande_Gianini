
import rasterio
from rasterio import features
import geopandas as gpd
from pyproj import CRS
import numpy as np
from shapely.geometry import LineString, shape
from pysheds.grid import Grid
import os

def processar_mde_pysheds(mde_path, output_dir):
    """
    Processes a DEM to generate hydrological inputs.

    Args:
        mde_path (str): Path to the Digital Elevation Model (DEM) file.
        output_dir (str): Directory to save the results.

    Returns:
        tuple: A tuple containing paths to the generated files.
    """
    try:
        grid = Grid.from_raster(mde_path, data_name='dem')
        dem = grid.read_raster(mde_path)

        pit_filled_dem = grid.fill_pits(dem)
        flooded_dem = grid.fill_depressions(pit_filled_dem)
        inflated_dem = grid.resolve_flats(flooded_dem)

        dirmap = (64, 128, 1, 2, 4, 8, 16, 32)
        fdir = grid.flowdir(inflated_dem, dirmap=dirmap)
        acc = grid.accumulation(fdir, dirmap=dirmap)

        fdir_path = os.path.join(output_dir, 'flow_direction.tif')
        acc_path = os.path.join(output_dir, 'flow_accumulation.tif')

        grid.to_raster(fdir, fdir_path, nodata=-9999)
        grid.to_raster(acc, acc_path, nodata=-9999)

        return fdir_path, acc_path, grid, fdir, acc, dirmap, inflated_dem

    except Exception as e:
        print(f"Error processing DEM: {e}")
        return None

def calcular_slope_aspect_twi(grid, inflated_dem, acc, output_dir):
    """
    Calculates slope, aspect, and TWI.

    Args:
        grid (Grid): The PySheds grid object.
        inflated_dem (np.ndarray): The conditioned DEM.
        acc (np.ndarray): The flow accumulation raster.
        output_dir (str): Directory to save the results.

    Returns:
        tuple: Paths to the slope, aspect, and TWI files.
    """
    try:
        gy, gx = np.gradient(inflated_dem)
        aspect_rad = np.arctan2(gy, -gx)
        aspect_deg = np.degrees(aspect_rad)
        aspect = (aspect_deg + 360) % 360
        aspect[((gx == 0) & (gy == 0))] = -1
        aspect_path = os.path.join(output_dir, 'aspect.tif')
        grid.to_raster(aspect, aspect_path, nodata=-1)

        x_res = grid.viewfinder.affine[0]
        y_res = -grid.viewfinder.affine[4]
        gy, gx = np.gradient(inflated_dem, y_res, x_res)
        slope_rad = np.arctan(np.sqrt(gx**2 + gy**2))
        slope_deg = np.degrees(slope_rad)
        slope_path = os.path.join(output_dir, 'slope.tif')
        grid.to_raster(slope_deg, slope_path, nodata=-9999)

        cell_area = x_res * y_res
        slope_rad[slope_rad == 0] = 0.001
        sca = (acc + 1) * cell_area
        twi = np.log(sca / np.tan(slope_rad))
        twi_path = os.path.join(output_dir, 'twi.tif')
        grid.to_raster(twi, twi_path, nodata=-9999)

        return slope_path, aspect_path, twi_path

    except Exception as e:
        print(f"Error calculating slope, aspect, or TWI: {e}")
        return None

def calcular_hand(grid, fdir, inflated_dem, acc, stream_threshold, channel_depth, output_dir):
    """
    Calculates the HAND model and generates a flood map.

    Args:
        grid (Grid): The PySheds grid object.
        fdir (np.ndarray): The flow direction raster.
        inflated_dem (np.ndarray): The conditioned DEM.
        acc (np.ndarray): The flow accumulation raster.
        stream_threshold (int): The stream threshold.
        channel_depth (float): The channel depth.
        output_dir (str): Directory to save the results.

    Returns:
        str: Path to the flood map GeoJSON.
    """
    try:
        streams_mask_global = acc > stream_threshold
        hand = grid.compute_hand(fdir, inflated_dem, streams_mask_global)

        hand_view = grid.view(hand, nodata=np.nan)
        inundation_depth = np.where(hand_view < channel_depth, channel_depth - hand_view, np.nan)

        profile = {
            'crs': grid.viewfinder.crs,
            'transform': grid.viewfinder.affine,
            'height': grid.viewfinder.shape[0],
            'width': grid.viewfinder.shape[1],
            'driver': 'GTiff',
            'count': 1,
            'dtype': rasterio.float32,
            'nodata': np.nan
        }

        suffix_nome_arquivo = f"{str(channel_depth).replace('.', '_')}m"
        inundacao_raster_path = os.path.join(output_dir, f'inundacao_mapa_{suffix_nome_arquivo}.tif')
        with rasterio.open(inundacao_raster_path, 'w', **profile) as dst:
            dst.write(inundation_depth.astype(rasterio.float32), 1)

        inundation_mask = ~np.isnan(inundation_depth)
        shapes_generator = rasterio.features.shapes(
            inundation_mask.astype(np.uint8),
            mask=inundation_mask,
            transform=profile['transform']
        )

        flood_geometries = [shape(geom) for geom, value in shapes_generator if value == 1]
        flood_gdf_temp = gpd.GeoDataFrame(geometry=flood_geometries, crs=profile['crs'])
        flood_gdf_temp['id'] = 1
        flood_gdf_dissolved = flood_gdf_temp.dissolve(by='id')

        inundacao_vetor_path = os.path.join(output_dir, f'inundacao_{suffix_nome_arquivo}.geojson')
        flood_gdf_dissolved.to_file(inundacao_vetor_path, driver='GeoJSON')

        return inundacao_vetor_path

    except Exception as e:
        print(f"Error calculating HAND: {e}")
        return None
