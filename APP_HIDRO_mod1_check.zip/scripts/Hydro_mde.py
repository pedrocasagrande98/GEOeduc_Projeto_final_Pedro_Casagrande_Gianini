# Módulo 2: Análise Hidrológica a partir do MDE
# Esta página será desenvolvida futuramente.

import streamlit as st

st.title("Módulo 2: Análise Hidrológica")
st.write("Em desenvolvimento...")
