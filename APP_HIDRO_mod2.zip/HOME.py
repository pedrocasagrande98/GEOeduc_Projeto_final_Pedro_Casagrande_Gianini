import streamlit as st

st.set_page_config(
    page_title="Análise Hidrográfica Integrada",
    page_icon="🌿"
)

st.title("🌿 Análise Hidrográfica Integrada 🛰️")

st.markdown("---")

st.markdown("Bem-vindo à Análise Hidrográfica Integrada! Esta aplicação utiliza dados geoespaciais para fornecer insights sobre bacias hidrográficas, redes de drenagem e muito mais.")

st.markdown("### Como usar:")
st.info("""
1.  **Navegue até a página 'Análise Hidrográfica' na barra lateral.**
2.  **Insira as coordenadas de latitude e longitude do ponto de interesse.**
3.  **Aguarde a análise e explore os resultados, incluindo mapas, dados e gráficos.**
""")

st.markdown("---")

st.image("https://i.imgur.com/rztB5pr.png", caption="Visualização da Bacia Hidrográfica e Rede de Drenagem")
