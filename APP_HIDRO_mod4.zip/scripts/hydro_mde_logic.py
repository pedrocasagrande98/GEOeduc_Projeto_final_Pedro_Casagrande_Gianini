import rasterio
import geopandas as gpd
import numpy as np
from shapely.geometry import LineString
import warnings
import os

try:
    from pysheds.grid import Grid
except ImportError:
    print("Erro: Biblioteca 'pysheds' não encontrada. Instale com 'pip install pysheds'")
    raise

warnings.filterwarnings("ignore", category=FutureWarning)

def process_dem_for_hydro_analysis(input_dem_path, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    print(f"Diretório de saída: '{output_dir}'")

    try:
        if not os.path.exists(input_dem_path):
            raise FileNotFoundError(f"Arquivo MDE '{input_dem_path}' não encontrado.")

        grid = Grid.from_raster(input_dem_path, data_name='dem')
        dem = grid.read_raster(input_dem_path)

        print("Condicionando MDE...")
        pit_filled_dem = grid.fill_pits(dem)
        flooded_dem = grid.fill_depressions(pit_filled_dem)
        inflated_dem = grid.resolve_flats(flooded_dem)

        print("Calculando direção e acumulação do fluxo...")
        dirmap = (64, 128, 1, 2, 4, 8, 16, 32)
        fdir = grid.flowdir(inflated_dem, dirmap=dirmap)
        acc = grid.accumulation(fdir, dirmap=dirmap)

        fdir_path = os.path.join(output_dir, 'flow_direction.tif')
        acc_path = os.path.join(output_dir, 'flow_accumulation.tif')

        print(f"Salvando raster de direção de fluxo em '{fdir_path}'...")
        grid.to_raster(fdir, fdir_path, blockxsize=16, blockysize=16, nodata=-9999)

        print(f"Salvando raster de acumulação de fluxo em '{acc_path}'...")
        grid.to_raster(acc, acc_path, blockxsize=16, blockysize=16, nodata=-9999)

        print("Processamento de direção e acumulação concluído com sucesso!")
        return fdir_path, acc_path, grid

    except Exception as e:
        print(f"Erro inesperado durante o processamento do MDE: {e}")
        raise

def extract_strahler_network(fdir_path, acc_path, grid, output_dir, stream_threshold):
    try:
        fdir = grid.read_raster(fdir_path)
        acc = grid.read_raster(acc_path)

        print(f"Identificando canais com limiar de acumulação > {stream_threshold}...")
        streams_mask = acc > stream_threshold

        print("Calculando a ordem de Strahler para a rede de drenagem...")
        stream_order_raster = grid.stream_order(fdir, streams_mask)

        print("Extraindo a rede de drenagem como feições vetoriais...")
        network = grid.extract_river_network(fdir, streams_mask, distance=1)

        print("Atribuindo a ordem de Strahler a cada segmento de rio...")
        features = network['features']
        geometries = []
        strahler_orders = []

        if not features:
            print("Aviso: Nenhuma feição de canal encontrada na rede extraída.")
            return None

        affine = grid.affine
        height, width = grid.shape

        for feature in features:
            coords = feature['geometry']['coordinates']
            if len(coords) >= 2:
                line = LineString(coords)
                geometries.append(line)
                
                try:
                    start_coord = coords[0]
                    inv_affine = ~affine
                    col_frac, row_frac = inv_affine * (start_coord[0], start_coord[1])
                    row, col = int(row_frac), int(col_frac)

                    if 0 <= row < height and 0 <= col < width:
                        order_val = stream_order_raster[row, col]
                        strahler_orders.append(int(order_val))
                    else:
                        strahler_orders.append(None)
                except Exception:
                    strahler_orders.append(None)
            
        if geometries:
            streams_gdf = gpd.GeoDataFrame({'strahler_order': strahler_orders}, geometry=geometries, crs=grid.crs)
            canais_path = os.path.join(output_dir, 'canais_strahler_full.geojson')
            streams_gdf.to_file(canais_path, driver='GeoJSON')
            print(f"Canais (com ordem de Strahler) salvos em: '{canais_path}'")
            return canais_path
        else:
            print("Nenhum canal válido para salvar.")
            return None

    except Exception as e:
        print(f"Erro inesperado durante a extração da rede de drenagem: {e}")
        raise
