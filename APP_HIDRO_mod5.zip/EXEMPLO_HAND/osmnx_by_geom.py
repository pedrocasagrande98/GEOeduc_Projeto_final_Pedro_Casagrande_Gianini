import geopandas as gpd
import os
import numpy as np
from pyproj import CRS
import warnings

# Ignorar warnings futuros
warnings.filterwarnings("ignore", category=FutureWarning)

# --- Configurações e Caminhos de Entrada ---
# Ajuste estes caminhos conforme a localização dos seus arquivos
OUTPUT_DIR = 'resultados_inundacao' # Diretório onde os arquivos de saída foram/serão salvos
inundacao_vetor_path = os.path.join(OUTPUT_DIR, 'inundacao.geojson')
osm_polygons_path = os.path.join(OUTPUT_DIR, 'osm_polygons.gpkg')

# Cria o diretório de saída se não existir (necessário para os logs ou futuros outputs)
os.makedirs(OUTPUT_DIR, exist_ok=True)

print("--- Iniciando Análise de Interseção (Inundação vs Polígonos OSM) ---")

try:
    # --- Carregar Vetor de Inundação ---
    flood_analysis_gdf = gpd.GeoDataFrame(geometry=[])
    if os.path.exists(inundacao_vetor_path):
        print(f"Carregando vetor de inundação '{inundacao_vetor_path}'...")
        flood_analysis_gdf = gpd.read_file(inundacao_vetor_path)
        if len(flood_analysis_gdf) > 1:
            print("Aviso: Vetor de inundação contém múltiplas features. Dissolvendo para uma única...")
            flood_analysis_gdf['temp_id'] = 1
            flood_analysis_gdf = flood_analysis_gdf.dissolve(by='temp_id')
        print(f"Vetor de inundação carregado (CRS: {flood_analysis_gdf.crs}).")
    else:
        print(f"Aviso: Arquivo vetorial de inundação '{inundacao_vetor_path}' não encontrado. A análise de interseção pode ser limitada.")
        # Tenta obter um CRS de fallback se o arquivo não existir, para evitar erros de CRS None
        # Se o raster de inundação não foi gerado, este fallback também falhará, mas é uma tentativa.
        # Para um script 100% independente, talvez seja melhor definir um CRS padrão aqui.
        # Por simplicidade, vamos assumir que se o vetor não existe, o CRS será inferido do OSM ou definido como 4326.
        flood_analysis_gdf = gpd.GeoDataFrame(geometry=[], crs=CRS.from_epsg(4326)) # Default CRS

    # --- Carregar Polígonos OSM e Harmonizar CRS ---
    osm_polygons_gdf_input = gpd.GeoDataFrame(geometry=[])
    if os.path.exists(osm_polygons_path):
        osm_polygons_gdf_input = gpd.read_file(osm_polygons_path)
        print(f"Vetor de polígonos OSM '{osm_polygons_path}' carregado (CRS: {osm_polygons_gdf_input.crs}).")
    else:
        print(f"Aviso: Arquivo de polígonos OSM '{osm_polygons_path}' não encontrado. Análise de interseção não será realizada.")
        osm_polygons_gdf = gpd.GeoDataFrame(geometry=[], crs=CRS.from_epsg(4326)) # Default CRS
        # Pula o restante da lógica de harmonização e filtragem se não há polígonos OSM
        total_polygons_aoi = 0
        count_affected_polygons = 0
        print("--- Análise Concluída (sem polígonos OSM) ---")
        exit() # Sai do script se não há dados OSM para analisar

    # Determinar o CRS alvo para harmonização
    target_crs = None
    if not flood_analysis_gdf.empty and flood_analysis_gdf.crs:
        target_crs = flood_analysis_gdf.crs
    elif not osm_polygons_gdf_input.empty and osm_polygons_gdf_input.crs:
        target_crs = osm_polygons_gdf_input.crs
    else:
        print("Erro: Não foi possível determinar um CRS alvo para harmonização. Ambos os GeoDataFrames estão vazios ou sem CRS.")
        exit()

    if osm_polygons_gdf_input.crs != target_crs:
        print(f"Reprojetando polígonos OSM de {osm_polygons_gdf_input.crs} para {target_crs}...")
        osm_polygons_gdf = osm_polygons_gdf_input.to_crs(target_crs)
    else:
        print("CRS dos polígonos OSM e inundação são compatíveis ou já harmonizados.")
        osm_polygons_gdf = osm_polygons_gdf_input


    # --- Filtrar polígonos de 'water' ---
    print(f"Total de polígonos OSM antes da filtragem: {len(osm_polygons_gdf)}")

    if 'natural' in osm_polygons_gdf.columns:
        print("Filtrando polígonos com 'natural' == 'water'...")
        osm_polygons_gdf = osm_polygons_gdf[
            osm_polygons_gdf['natural'].fillna('') != 'water'
        ]

    if 'water' in osm_polygons_gdf.columns:
        print("Filtrando polígonos com a tag 'water' preenchida...")
        osm_polygons_gdf = osm_polygons_gdf[
            osm_polygons_gdf['water'].isna()
        ]

    print(f"Total de polígonos OSM após a filtragem (sem 'water'): {len(osm_polygons_gdf)}")


    # --- Análise de Interseção ---
    print("Realizando interseção espacial (Inundação vs Polígonos OSM)...")
    affected_polygons_gdf = gpd.GeoDataFrame(geometry=[], crs=target_crs)

    if not osm_polygons_gdf.empty and not flood_analysis_gdf.empty:
        if osm_polygons_gdf.crs != flood_analysis_gdf.crs:
            print(f"Erro: CRS não coincidem ({osm_polygons_gdf.crs} vs {flood_analysis_gdf.crs}). Interseção não realizada.")
        else:
            affected_sjoin = gpd.sjoin(osm_polygons_gdf, flood_analysis_gdf, how='inner', predicate='intersects')
            # Remove duplicatas de índice que podem surgir do sjoin se um polígono OSM intersecta múltiplas partes do polígono de inundação
            affected_polygons_gdf = affected_sjoin[~affected_sjoin.index.duplicated(keep='first')]
    else:
        print("Não há dados de polígonos OSM (pós-filtro) ou inundação para realizar a interseção.")


    # --- Estatísticas ---
    count_affected_polygons = len(affected_polygons_gdf)
    total_polygons_aoi = len(osm_polygons_gdf)

    # --- Imprimir Estatísticas ---
    print("-" * 30)
    print("Estatísticas da Análise de Impacto (Polígonos OSM):")
    print(f"Número total de polígonos OSM na AOI (excluindo 'water'): {total_polygons_aoi}")
    print(f"Número de polígonos OSM afetados pela inundação: {count_affected_polygons}")
    if total_polygons_aoi > 0:
        percent_affected = (count_affected_polygons / total_polygons_aoi) * 100
        print(f"Percentual de polígonos OSM afetados: {percent_affected:.2f}%")
    else:
        print(f"Percentual de polígonos OSM afetados: N/A (nenhum polígono OSM na AOI)")
    print("-" * 30)

    print("--- Análise Concluída com Sucesso! ---")

except Exception as e:
    print(f"Erro inesperado durante a execução: {e}")
    # Em um script standalone, é comum sair com um código de erro
    exit(1)
