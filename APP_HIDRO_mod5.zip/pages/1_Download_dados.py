import streamlit as st
import geopandas as gpd
import ee
import geemap.foliumap as geemap
import requests
import os
from scripts.MDE_LULC import initialize_earth_engine, download_image_ano, export_to_drive

st.title("Download de Dados Geoespaciais")

st.markdown("""
    <style>
    html, body, [class*="st-"] {
        font-size: 1.1rem;
    }
    </style>
""", unsafe_allow_html=True)

with st.expander("Controles para Download de dados", expanded=True):
    user_id = st.text_input("Seu User ID do Google Earth Engine:", help="Seu projeto GEE deve ter o nome 'ee-SEU_USER_ID'")
    uploaded_gpkg = st.file_uploader("Upload de arquivo GPKG/GeoJSON", type=["gpkg", "geojson"])

if user_id and uploaded_gpkg:
    if initialize_earth_engine(user_id):
        gdf = gpd.read_file(uploaded_gpkg)
        if gdf.crs != "EPSG:4326":
            gdf = gdf.to_crs(epsg=4326)
        
        AOI = ee.FeatureCollection(gdf.__geo_interface__)
        clip_geometry = AOI.geometry().bounds()

        data_type = st.selectbox("Escolha o tipo de dado:", 
                                ["Elevação", "Declividade", "Aspecto", "Uso e Cobertura do Solo (MapBiomas)"])

        image_to_process = None
        vis_params = {}

        if data_type == "Elevação":
            elevation_palette = st.selectbox("Paleta de Cores (Elevação):", 
                                             ['terrain', 'viridis', 'inferno', 'gist_earth'])
            image_to_process = ee.Image('USGS/SRTMGL1_003').select('elevation').clip(clip_geometry)
            stats = image_to_process.reduceRegion(reducer=ee.Reducer.minMax(), geometry=clip_geometry, scale=30, maxPixels=1e9).getInfo()
            vis_params = {'min': stats['elevation_min'], 'max': stats['elevation_max'], 'palette': elevation_palette}
        
        elif data_type == "Declividade":
            slope_palette_name = st.selectbox("Paleta de Cores (Declividade):",
                                              ['Padrão (Verde-Vermelho)', 'Reds', 'plasma'])
            slope_palettes = {
                'Padrão (Verde-Vermelho)': ['#4CAF50', '#FFF176', '#FF7043', '#E53935'],
                'Reds': 'Reds',
                'plasma': 'plasma'
            }
            elevation = ee.Image('USGS/SRTMGL1_003').select('elevation')
            image_to_process = ee.Terrain.slope(elevation).clip(clip_geometry)
            stats = image_to_process.reduceRegion(reducer=ee.Reducer.minMax(), geometry=clip_geometry, scale=30, maxPixels=1e9).getInfo()
            vis_params = {'min': stats['slope_min'], 'max': stats['slope_max'], 'palette': slope_palettes[slope_palette_name]}

        elif data_type == "Aspecto":
            elevation = ee.Image('USGS/SRTMGL1_003').select('elevation')
            image_to_process = ee.Terrain.hillshade(elevation).clip(clip_geometry)
            vis_params = {}

        elif data_type == "Uso e Cobertura do Solo (MapBiomas)":
            mapbiomas_color_map = {"1": "#1f8d49", "3": "#1f8d49", "4": "#7dc975", "5": "#04381d", "6": "#026975", "9": "#7a5900", "10": "#ad975a", "11": "#519799", "12": "#d6bc74", "14": "#FFFFB2", "15": "#edde8e", "18": "#E974ED", "19": "#C27BA0", "20": "#db7093", "21": "#ffefc3", "22": "#d4271e", "23": "#ffa07a", "24": "#d4271e", "25": "#db4d4f", "26": "#0000FF", "27": "#ffffff", "29": "#ffaa5f", "30": "#9c0027", "31": "#091077", "32": "#fc8114", "33": "#2532e4", "35": "#9065d0", "36": "#d082de", "39": "#f5b3c8", "40": "#c71585", "41": "#f54ca9", "46": "#d68fe2", "47": "#9932cc", "48": "#e6ccff", "49": "#02d659", "50": "#ad5100", "62": "#ff69b4"}
            max_id = max([int(k) for k in mapbiomas_color_map.keys()])
            min_id = 0
            full_palette = [mapbiomas_color_map.get(str(i), '00000000').replace('#', '') for i in range(min_id, max_id + 1)]
            vis_params = {'min': min_id, 'max': max_id, 'palette': full_palette}
            selected_year = st.slider("Ano (MapBiomas):", 1985, 2023, 2023)
            band_name = f'classification_{selected_year}'
            image_to_process = ee.Image(f'projects/mapbiomas-public/assets/brazil/lulc/collection9/mapbiomas_collection90_integration_v1').select(band_name).clip(clip_geometry)

        if image_to_process is not None:
            action = st.radio("Escolha a ação:", ["Baixar Direto", "Exportar para Google Drive"], horizontal=True)
            if action == "Baixar Direto":
                file_name = st.text_input("Nome do arquivo para salvar (.tif):", "dados_processados.tif")
                if st.button("Iniciar Download"):
                    output_dir = "D:/POS/!FW_HAND_Osmnx/!PROJETO_FINAL_4_modulos/resultado/mod1"
                    if not os.path.exists(output_dir):
                        os.makedirs(output_dir)
                    output_path = os.path.join(output_dir, file_name)
                    download_image_ano(image_to_process, output_path, AOI)
            elif action == "Exportar para Google Drive":
                folder_name = st.text_input("Nome da pasta no Google Drive:", "Hydro_Analysis_Exports")
                if st.button("Iniciar Exportação"):
                    export_to_drive(image_to_process, AOI, folder_name)
        
        st.subheader("Visualização do Mapa")
        map_height = st.slider("Altura do mapa (pixels):", min_value=400, max_value=1200, value=700, step=50)

        m = geemap.Map(center=[-15.78, -47.92], zoom=4, plugin_Draw=True, Draw_export=True)
        m.add_basemap("HYBRID")

        if AOI is not None:
            m.centerObject(AOI, 10)
            m.addLayer(AOI, {'color': 'cyan', 'fillColor': 'cyan'}, 'Área de Interesse', True, 0.5)

        if image_to_process is not None:
            m.addLayer(image_to_process, vis_params, f'Visualização: {data_type}')
        
        m.to_streamlit(height=map_height)

else:
    st.info("Por favor, insira seu User ID do GEE e faça o upload de um arquivo para continuar.")
