import streamlit as st
import os
import tempfile
from scripts.hydro_mde_logic import process_dem_for_hydro_analysis, extract_strahler_network

st.title("Processamento de Imagem MDE")

st.markdown("""
    <style>
    html, body, [class*="st-"] {
        font-size: 1.1rem;
    }
    </style>
""", unsafe_allow_html=True)

with st.expander("Controles para Hydro MDE", expanded=True):
    uploaded_file = st.file_uploader("Selecione a imagem MDE", type=["tif", "tiff"])
    stream_threshold = st.number_input("Limiar de Acumulação de Fluxo", min_value=100, max_value=10000, value=1000, step=100)

if uploaded_file is not None:
    st.success(f"Arquivo '{uploaded_file.name}' carregado com sucesso!")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_input_path = os.path.join(temp_dir, uploaded_file.name)
        with open(temp_input_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
        
        output_dir = "D:/POS/!FW_HAND_Osmnx/!PROJETO_FINAL_4_modulos/resultado/mod2"
        
        with st.spinner("Processando MDE..."):
            fdir_path, acc_path, grid = process_dem_for_hydro_analysis(temp_input_path, output_dir)
            st.success("Direção e acumulação de fluxo calculados.")

        with st.spinner("Extraindo rede de drenagem..."):
            canais_path = extract_strahler_network(fdir_path, acc_path, grid, output_dir, stream_threshold)
            if canais_path:
                st.success(f"Rede de drenagem extraída e salva em: {canais_path}")
            else:
                st.warning("Não foi possível extrair a rede de drenagem.")
