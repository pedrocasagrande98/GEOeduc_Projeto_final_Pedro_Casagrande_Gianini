import streamlit as st
import os
import tempfile
from scripts.basin_logic import delimit_watershed

st.title("Delimitação de Bacias Hidrográficas")

st.markdown("""
    <style>
    html, body, [class*="st-"] {
        font-size: 1.1rem;
    }
    </style>
""", unsafe_allow_html=True)

with st.expander("Controles para Delimitação de Bacia", expanded=True):
    uploaded_file = st.file_uploader("Selecione a imagem MDE", type=["tif", "tiff"])
    col1, col2 = st.columns(2)
    with col1:
        lat_outlet = st.number_input("Latitude do Exutório", format="%.6f")
    with col2:
        lon_outlet = st.number_input("Longitude do Exutório", format="%.6f")
    stream_threshold = st.number_input("Limiar de Acumulação de Fluxo", min_value=100, max_value=10000, value=1000, step=100)
    
    if st.button("Iniciar Delimitação"):
        if uploaded_file is not None:
            with tempfile.TemporaryDirectory() as temp_dir:
                temp_input_path = os.path.join(temp_dir, uploaded_file.name)
                with open(temp_input_path, "wb") as f:
                    f.write(uploaded_file.getbuffer())
                
                output_dir = "D:/POS/!FW_HAND_Osmnx/!PROJETO_FINAL_4_modulos/resultado/mod3"
                outlet_coords = (lon_outlet, lat_outlet)
                
                with st.spinner("Delimitando bacia hidrográfica..."):
                    try:
                        bacia_path = delimit_watershed(temp_input_path, output_dir, outlet_coords, stream_threshold)
                        st.success(f"Bacia hidrográfica delimitada e salva em: {bacia_path}")
                    except Exception as e:
                        st.error(f"Ocorreu um erro durante a delimitação: {e}")
        else:
            st.warning("Por favor, faça o upload de uma imagem MDE para continuar.")
