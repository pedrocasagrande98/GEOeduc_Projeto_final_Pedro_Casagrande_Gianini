import streamlit as st
import os
import numpy as np
import rasterio
from pysheds.grid import Grid
import tempfile

st.set_page_config(layout="wide")

st.title("🌊 Cálculo de Mancha de Inundação com HAND")

st.markdown(
    """
    Esta página permite calcular a mancha de inundação para uma área completa
    a partir de um Modelo Digital de Elevação (MDE) usando o método HAND
    (Height Above Nearest Drainage).
    """
)

# --- Função de Cálculo HAND (adaptada do script original) ---
@st.cache_data
def calculate_inundation_for_full_dem(
    input_dem_path: str,
    output_tif_path: str,
    stream_threshold: int = 1000,
    channel_depth: float = 10.0,
):
    """
    Executa o fluxo de cálculo de inundação para a área completa de um MDE.

    Args:
        input_dem_path (str): Caminho para o arquivo MDE de entrada (GeoTIFF).
        output_tif_path (str): Caminho para salvar o raster de inundação de saída (GeoTIFF).
        stream_threshold (int): Limiar de acumulação para definir a rede de drenagem.
        channel_depth (float): Profundidade do canal em metros para simular a inundação.
    """
    st.info(f"Iniciando Processo de Cálculo de Inundação (MDE Completo) para {os.path.basename(input_dem_path)}...")

    if not os.path.exists(input_dem_path):
        st.error(f"Arquivo MDE de entrada não encontrado: '{input_dem_path}'")
        return None

    # --- 1. Carregar MDE e Condicionamento Hidrológico ---
    st.write("1. Carregando MDE e instanciando PySheds Grid...")
    grid = Grid.from_raster(input_dem_path, data_name='dem')
    dem = grid.read_raster(input_dem_path)

    st.write("   Condicionando MDE (fill_pits, fill_depressions, resolve_flats)...")
    pit_filled_dem = grid.fill_pits(dem)
    flooded_dem = grid.fill_depressions(pit_filled_dem)
    inflated_dem = grid.resolve_flats(flooded_dem)

    # --- 2. Direção e Acumulação de Fluxo ---
    st.write("2. Calculando direção e acumulação de fluxo para o MDE completo...")
    dirmap = (64, 128, 1, 2, 4, 8, 16, 32)
    fdir = grid.flowdir(inflated_dem, dirmap=dirmap)
    acc = grid.accumulation(fdir, dirmap=dirmap)

    # --- 3. Cálculo do HAND ---
    st.write(f"3. Definindo rede de drenagem com limiar de {stream_threshold}...")
    streams_mask = acc > stream_threshold

    st.write("   Calculando HAND (Height Above Nearest Drainage) para o MDE completo...")
    hand = grid.compute_hand(fdir, inflated_dem, streams_mask)

    # --- 4. Geração da Mancha de Inundação ---
    st.write(f"4. Gerando mancha de inundação para uma profundidade de {channel_depth}m...")
    hand_view = grid.view(hand, nodata=np.nan)
    inundation_depth = np.where(hand_view < channel_depth, channel_depth - hand_view, np.nan)

    # --- 5. Salvando o Raster de Saída ---
    st.write(f"5. Salvando raster de inundação em '{output_tif_path}'...")
    output_dir = os.path.dirname(output_tif_path)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    profile = {
        'crs': grid.viewfinder.crs,
        'transform': grid.viewfinder.affine,
        'height': grid.shape[0],
        'width': grid.shape[1],
        'driver': 'GTiff',
        'count': 1,
        'dtype': rasterio.float32,
        'nodata': np.nan
    }

    with rasterio.open(output_tif_path, 'w', **profile) as dst:
        dst.write(inundation_depth.astype(rasterio.float32), 1)

    st.success(f"Processo concluído com sucesso! Resultado salvo em: {output_tif_path}")
    return output_tif_path

# --- Interface Streamlit ---

uploaded_file = st.file_uploader("Faça upload do seu arquivo MDE (GeoTIFF)", type=["tif", "tiff"])

if uploaded_file is not None:
    st.success("Arquivo MDE carregado com sucesso!")

    # Salva o arquivo temporariamente para que pysheds possa lê-lo
    with tempfile.NamedTemporaryFile(delete=False, suffix=".tif") as tmp_dem_file:
        tmp_dem_file.write(uploaded_file.getvalue())
        input_dem_path = tmp_dem_file.name
    
    st.sidebar.header("Parâmetros de Análise HAND")
    stream_threshold = st.sidebar.number_input(
        "Limiar de Acumulação (Stream Threshold)",
        min_value=100,
        max_value=100000,
        value=1000,
        step=100,
        help="Define o que é considerado um rio. Valores menores = mais rios; valores maiores = apenas rios principais."
    )
    channel_depth = st.sidebar.number_input(
        "Profundidade do Canal (metros)",
        min_value=0.1,
        max_value=100.0,
        value=10.0,
        step=0.5,
        help="Altura da água acima do fundo do canal para simular a inundação."
    )

    if st.button("Executar Cálculo HAND"):
        with st.spinner("Calculando mancha de inundação... Isso pode levar alguns minutos."):
            try:
                # Define o diretório de saída e cria-o se não existir
                output_dir = "resultado/mod4"
                os.makedirs(output_dir, exist_ok=True)
                
                # Constrói o caminho completo para o arquivo de saída
                output_filename = f"inundacao_hand_{os.path.splitext(uploaded_file.name)[0]}.tif"
                output_tif_path = os.path.join(output_dir, output_filename)

                result_path = calculate_inundation_for_full_dem(
                    input_dem_path=input_dem_path,
                    output_tif_path=output_tif_path,
                    stream_threshold=stream_threshold,
                    channel_depth=channel_depth,
                )

                if result_path:
                    st.subheader("Resultado:")
                    st.success(f"Cálculo concluído! O arquivo foi salvo em: {result_path}")
                    
                    st.markdown("---") # Separator
                    st.write("Seu download está pronto. Por favor, clique no botão abaixo para baixar o arquivo.")
                    with open(result_path, "rb") as f:
                        st.download_button(
                            label="Baixar Mancha de Inundação (GeoTIFF)",
                            data=f.read(),
                            file_name=output_filename,
                            mime="application/octet-stream"
                        )
                    
                    # Opcional: Exibir o mapa (requer bibliotecas como folium ou pydeck e conversão para visualização)
                    st.info("Para visualizar o resultado diretamente aqui, você precisaria de uma biblioteca de mapeamento (e.g., folium, kepler.gl) e talvez converter o GeoTIFF para um formato web-friendly (e.g., PNG, GeoJSON).")

            except Exception as e:
                st.error(f"Ocorreu um erro durante a execução do cálculo HAND: {e}")
            finally:
                # Limpa o arquivo temporário de entrada do DEM
                if 'input_dem_path' in locals() and os.path.exists(input_dem_path):
                    os.remove(input_dem_path)
                # O arquivo de saída agora é persistente em 'resultado/mod4', então não o removemos aqui.
else:
    st.info("Por favor, faça o upload de um arquivo MDE (GeoTIFF) para começar.")
