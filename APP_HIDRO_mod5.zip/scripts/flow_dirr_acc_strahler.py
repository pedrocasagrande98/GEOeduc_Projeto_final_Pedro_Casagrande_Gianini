# hydro_mde_v2.py
#
# Este script realiza uma análise hidrológica para extrair a rede de drenagem
# de um Modelo Digital de Elevação (MDE) para toda a sua extensão.
#
# O fluxo inclui:
# 1. Condicionamento do MDE e cálculo de direção e acumulação de fluxo, salvando os rasters.
# 2. Extração da rede de drenagem com ordem de Strahler (sem delimitação de bacia).

# --- Bibliotecas ---
import rasterio
import geopandas as gpd
import numpy as np
from shapely.geometry import LineString
import warnings
import os

try:
    from pysheds.grid import Grid
except ImportError:
    print("Erro: Biblioteca 'pysheds' não encontrada. Instale com 'pip install pysheds'")
    raise

# Ignorar warnings futuros
warnings.filterwarnings("ignore", category=FutureWarning)

# --- Parâmetros Globais ---
INPUT_MDE_PATH = 'srtm_data.tif'
OUTPUT_DIR = 'resultados_inundacao'
STREAM_THRESHOLD = 1000

os.makedirs(OUTPUT_DIR, exist_ok=True)
print(f"Diretório de saída: '{OUTPUT_DIR}'")

# --- PARTE 1: Direção e Acumulação de Fluxo ---
print("\n--- Iniciando Parte 1: Direção e Acumulação de Fluxo ---")
try:
    if not os.path.exists(INPUT_MDE_PATH):
        raise FileNotFoundError(f"Arquivo MDE '{INPUT_MDE_PATH}' não encontrado.")

    grid = Grid.from_raster(INPUT_MDE_PATH, data_name='dem')
    dem = grid.read_raster(INPUT_MDE_PATH)

    print("Condicionando MDE...")
    pit_filled_dem = grid.fill_pits(dem)
    flooded_dem = grid.fill_depressions(pit_filled_dem)
    inflated_dem = grid.resolve_flats(flooded_dem)

    print("Calculando direção e acumulação do fluxo...")
    dirmap = (64, 128, 1, 2, 4, 8, 16, 32)
    fdir = grid.flowdir(inflated_dem, dirmap=dirmap)
    acc = grid.accumulation(fdir, dirmap=dirmap)

    # Exportar rasters de direção e acumulação
    fdir_path = os.path.join(OUTPUT_DIR, 'flow_direction.tif')
    acc_path = os.path.join(OUTPUT_DIR, 'flow_accumulation.tif')

    print(f"Salvando raster de direção de fluxo em '{fdir_path}'...")
    grid.to_raster(fdir, fdir_path, blockxsize=16, blockysize=16, nodata=-9999)

    print(f"Salvando raster de acumulação de fluxo em '{acc_path}'...")
    grid.to_raster(acc, acc_path, blockxsize=16, blockysize=16, nodata=-9999)

    print("Parte 1 concluída com sucesso!")

except Exception as e:
    print(f"Erro inesperado na Parte 1: {e}")
    raise

# --- PARTE 2: Extração de Canais e Ordem de Strahler ---
print("\n--- Iniciando Parte 2: Extração de Canais e Ordem de Strahler ---")
try:
    print(f"Identificando canais com limiar de acumulação > {STREAM_THRESHOLD}...")
    streams_mask = acc > STREAM_THRESHOLD

    print("Calculando a ordem de Strahler para a rede de drenagem...")
    stream_order_raster = grid.stream_order(fdir, streams_mask)

    print("Extraindo a rede de drenagem como feições vetoriais...")
    network = grid.extract_river_network(fdir, streams_mask, distance=1)

    print("Atribuindo a ordem de Strahler a cada segmento de rio...")
    features = network['features']
    geometries = []
    strahler_orders = []

    if not features:
        print("Aviso: Nenhuma feição de canal encontrada na rede extraída.")
        canais_path = None
    else:
        affine = grid.affine
        height, width = grid.shape

        for feature in features:
            coords = feature['geometry']['coordinates']
            if len(coords) >= 2:
                line = LineString(coords)
                geometries.append(line)
                
                try:
                    start_coord = coords[0]
                    inv_affine = ~affine
                    col_frac, row_frac = inv_affine * (start_coord[0], start_coord[1])
                    row, col = int(row_frac), int(col_frac)

                    if 0 <= row < height and 0 <= col < width:
                        order_val = stream_order_raster[row, col]
                        strahler_orders.append(int(order_val))
                    else:
                        strahler_orders.append(None)
                except Exception:
                    strahler_orders.append(None)
            
        if geometries:
            streams_gdf = gpd.GeoDataFrame({'strahler_order': strahler_orders}, geometry=geometries, crs=grid.crs)
            canais_path = os.path.join(OUTPUT_DIR, 'canais_strahler_full.geojson')
            streams_gdf.to_file(canais_path, driver='GeoJSON')
            print(f"Canais (com ordem de Strahler) salvos em: '{canais_path}'")
        else:
            print("Nenhum canal válido para salvar.")
            canais_path = None

    print("Parte 2 concluída com sucesso!")
    if canais_path:
        print(f"Arquivo gerado: '{canais_path}'")

except Exception as e:
    print(f"Erro inesperado na Parte 2: {e}")
    raise
