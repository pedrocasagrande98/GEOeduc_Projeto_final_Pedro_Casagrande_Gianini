import rasterio
import rasterio.features
import geopandas as gpd
import numpy as np
from shapely.geometry import shape
import warnings
import os

try:
    from pysheds.grid import Grid
except ImportError:
    print("Erro: Biblioteca 'pysheds' não encontrada. Instale com 'pip install pysheds'")
    raise

warnings.filterwarnings("ignore", category=FutureWarning)

def calculate_hand(
    dem_path,
    fdir_path,
    acc_path,
    basin_path,
    output_dir,
    channel_depth,
    stream_threshold
):
    os.makedirs(output_dir, exist_ok=True)
    print(f"Diretório de saída: '{output_dir}'")

    try:
        # Carregar a bacia primeiro para definir a área de interesse
        basin_gdf = gpd.read_file(basin_path)
        basin_geom = basin_gdf.geometry.iloc[0]

        # Instanciar o grid e recortá-lo para a bacia ANTES de ler os rasters
        grid = Grid.from_raster(dem_path)
        grid.clip_to(basin_geom)

        # Ler os dados dos rasters já recortados pela visão do grid
        dem = grid.read_raster(dem_path)
        fdir = grid.read_raster(fdir_path)
        acc = grid.read_raster(acc_path)

        # Máscara de rios (agora usando a acumulação já recortada)
        streams_mask = acc > stream_threshold

        # HAND (calculado dentro da bacia usando a visão do grid)
        print("Calculando HAND dentro da bacia...")
        hand = grid.compute_hand(fdir, dem, streams_mask)

        print(f"Calculando mancha de inundação (profundidade) para {channel_depth}m...")
        hand_view = grid.view(hand, nodata=np.nan)
        inundation_depth = np.where(hand_view < channel_depth, channel_depth - hand_view, np.nan)

        # Salvar Raster de Inundação
        profile = {
            'crs': grid.viewfinder.crs,
            'transform': grid.viewfinder.affine,
            'height': grid.viewfinder.shape[0],
            'width': grid.viewfinder.shape[1],
            'driver': 'GTiff',
            'count': 1,
            'dtype': rasterio.float32,
            'nodata': np.nan
        }
        inundacao_raster_path = os.path.join(output_dir, 'inundacao_mapa.tif')
        with rasterio.open(inundacao_raster_path, 'w', **profile) as dst:
            dst.write(inundation_depth.astype(rasterio.float32), 1)
        print(f"Arquivo raster de inundação salvo como: '{inundacao_raster_path}'")

        # Vetorizar a Mancha de Inundação
        print("Vetorizando a mancha de inundação (área)...")
        inundation_mask = ~np.isnan(inundation_depth)

        if not np.any(inundation_mask):
            print("Aviso: Nenhuma área inundada encontrada para vetorizar.")
            return inundacao_raster_path, None

        shapes_generator = rasterio.features.shapes(
            inundation_mask.astype(np.uint8),
            mask=inundation_mask,
            transform=profile['transform']
        )

        flood_geometries = [shape(geom) for geom, value in shapes_generator if value == 1]

        if not flood_geometries:
            print("Aviso: Nenhuma geometria encontrada após a vetorização da máscara de inundação.")
            return inundacao_raster_path, None

        flood_gdf_temp = gpd.GeoDataFrame(geometry=flood_geometries, crs=profile['crs'])
        flood_gdf_temp['id'] = 1
        flood_gdf_dissolved = flood_gdf_temp.dissolve(by='id')

        inundacao_vetor_path = os.path.join(output_dir, 'inundacao.geojson')
        flood_gdf_dissolved.to_file(inundacao_vetor_path, driver='GeoJSON')
        print(f"Arquivo vetorial de inundação salvo como: '{inundacao_vetor_path}'")

        return inundacao_raster_path, inundacao_vetor_path

    except Exception as e:
        print(f"Erro inesperado durante o cálculo do HAND: {e}")
        raise
