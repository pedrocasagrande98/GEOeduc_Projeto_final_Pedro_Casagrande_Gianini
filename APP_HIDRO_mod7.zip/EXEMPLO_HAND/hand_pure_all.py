# -*- coding: utf-8 -*-
"""
Script Python puro para cálculo de mancha de inundação usando HAND
para a área completa de um MDE, sem necessidade de exutório.

Este script encapsula a lógica hidrológica para:
1. Condicionar um Modelo Digital de Elevação (MDE).
2. Identificar a rede de drenagem em toda a área.
3. Calcular o índice HAND (Height Above Nearest Drainage) para o MDE completo.
4. Gerar um raster de mancha de inundação com base em uma profundidade de canal.

Para executar, modifique os parâmetros na seção '__main__' no final do arquivo
e rode o script diretamente: `python hand_pure_all.py`
"""

import os
import numpy as np
import rasterio

try:
    from pysheds.grid import Grid
except ImportError:
    print("Erro: Biblioteca 'pysheds' não encontrada. Instale com 'pip install pysheds'")
    raise

def calculate_inundation_for_full_dem(
    input_dem_path: str,
    output_tif_path: str,
    stream_threshold: int = 1000,
    channel_depth: float = 10.0,
):
    """
    Executa o fluxo de cálculo de inundação para a área completa de um MDE.

    Args:
        input_dem_path (str): Caminho para o arquivo MDE de entrada (GeoTIFF).
        output_tif_path (str): Caminho para salvar o raster de inundação de saída (GeoTIFF).
        stream_threshold (int): Limiar de acumulação para definir a rede de drenagem.
        channel_depth (float): Profundidade do canal em metros para simular a inundação.
    """
    print("--- Iniciando Processo de Cálculo de Inundação (MDE Completo) ---")

    if not os.path.exists(input_dem_path):
        raise FileNotFoundError(f"Arquivo MDE de entrada não encontrado: '{input_dem_path}'")

    # --- 1. Carregar MDE e Condicionamento Hidrológico ---
    print(f"1. Carregando MDE '{input_dem_path}' e instanciando PySheds Grid...")
    grid = Grid.from_raster(input_dem_path, data_name='dem')
    dem = grid.read_raster(input_dem_path)

    print("   Condicionando MDE (fill_pits, fill_depressions, resolve_flats)...")
    pit_filled_dem = grid.fill_pits(dem)
    flooded_dem = grid.fill_depressions(pit_filled_dem)
    inflated_dem = grid.resolve_flats(flooded_dem)

    # --- 2. Direção e Acumulação de Fluxo ---
    print("2. Calculando direção e acumulação de fluxo para o MDE completo...")
    dirmap = (64, 128, 1, 2, 4, 8, 16, 32)
    fdir = grid.flowdir(inflated_dem, dirmap=dirmap)
    acc = grid.accumulation(fdir, dirmap=dirmap)

    # --- 3. Cálculo do HAND ---
    print(f"3. Definindo rede de drenagem com limiar de {stream_threshold}...")
    streams_mask = acc > stream_threshold

    print("   Calculando HAND (Height Above Nearest Drainage) para o MDE completo...")
    hand = grid.compute_hand(fdir, inflated_dem, streams_mask)

    # --- 4. Geração da Mancha de Inundação ---
    print(f"4. Gerando mancha de inundação para uma profundidade de {channel_depth}m...")
    # Visualiza o HAND para a área completa
    hand_view = grid.view(hand, nodata=np.nan)
    # Calcula a profundidade da inundação onde HAND < channel_depth
    inundation_depth = np.where(hand_view < channel_depth, channel_depth - hand_view, np.nan)

    # --- 5. Salvando o Raster de Saída ---
    print(f"5. Salvando raster de inundação em '{output_tif_path}'...")
    # Cria o diretório de saída se não existir
    output_dir = os.path.dirname(output_tif_path)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    # Define o perfil do raster de saída usando as propriedades do grid original
    # (não há recorte, então usamos o viewfinder original)
    profile = {
        'crs': grid.viewfinder.crs,
        'transform': grid.viewfinder.affine,
        'height': grid.shape[0],
        'width': grid.shape[1],
        'driver': 'GTiff',
        'count': 1,
        'dtype': rasterio.float32,
        'nodata': np.nan
    }

    with rasterio.open(output_tif_path, 'w', **profile) as dst:
        dst.write(inundation_depth.astype(rasterio.float32), 1)

    print("\n--- Processo concluído com sucesso! ---")
    print(f"Resultado salvo em: {output_tif_path}")


# --- BLOCO DE EXECUÇÃO PRINCIPAL ---
if __name__ == "__main__":
    # --- CONFIGURE SEUS PARÂMETROS AQUI ---

    # 1. Caminho para o seu arquivo MDE (Modelo Digital de Elevação)
    #    Este script processará a área inteira deste arquivo.
    INPUT_DEM_PATH = "srtm_data.tif"

    # 2. Caminho onde o resultado da inundação será salvo
    OUTPUT_TIF_PATH = "resultados/inundacao_hand_full_area.tif"

    # 3. (Opcional) Limiar de acumulação para definir o que é um rio.
    #    Ajuste este valor para corresponder à densidade de drenagem desejada.
    #    Valores menores = mais rios. Valores maiores = apenas rios principais.
    STREAM_THRESHOLD = 1000

    # 4. (Opcional) Profundidade do canal em metros para simular a inundação.
    #    Este valor representa a altura da água acima do fundo do canal.
    CHANNEL_DEPTH_METERS = 10.0

    try:
        # Chama a função principal com os parâmetros definidos acima
        calculate_inundation_for_full_dem(
            input_dem_path=INPUT_DEM_PATH,
            output_tif_path=OUTPUT_TIF_PATH,
            stream_threshold=STREAM_THRESHOLD,
            channel_depth=CHANNEL_DEPTH_METERS,
        )
    except Exception as e:
        print(f"\nERRO: Ocorreu um erro durante a execução: {e}")
        # Em um ambiente de produção, você pode querer logar o traceback completo.
        # import traceback
        # traceback.print_exc()