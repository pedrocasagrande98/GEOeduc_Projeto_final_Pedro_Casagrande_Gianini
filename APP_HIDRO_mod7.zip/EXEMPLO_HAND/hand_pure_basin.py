# -*- coding: utf-8 -*-
"""
Script Python puro para cálculo de mancha de inundação usando HAND.

Este script encapsula a lógica hidrológica para:
1. Condicionar um Modelo Digital de Elevação (MDE).
2. Delimitar uma bacia hidrográfica a partir de um ponto de exutório.
3. Calcular o índice HAND (Height Above Nearest Drainage).
4. Gerar um raster de mancha de inundação com base em uma profundidade de canal.

É projetado para ser executado via linha de comando.

Exemplo de uso:
Para executar, modifique os parâmetros na seção '__main__' no final do arquivo
e rode o script diretamente: `python hand_pure.py`
"""

import os
import numpy as np
import rasterio

try:
    from pysheds.grid import Grid
except ImportError:
    print("Erro: Biblioteca 'pysheds' não encontrada. Instale com 'pip install pysheds'")
    raise

def calculate_inundation(
    input_dem_path: str,
    output_tif_path: str,
    outlet_coords: tuple,
    stream_threshold: int = 1000,
    channel_depth: float = 10.0,
):
    """
    Executa o fluxo completo de cálculo de inundação a partir de um MDE.

    Args:
        input_dem_path (str): Caminho para o arquivo MDE de entrada (GeoTIFF).
        output_tif_path (str): Caminho para salvar o raster de inundação de saída (GeoTIFF).
        outlet_coords (tuple): Tupla com as coordenadas (longitude, latitude) do exutório.
        stream_threshold (int): Limiar de acumulação para definir a rede de drenagem.
        channel_depth (float): Profundidade do canal em metros para simular a inundação.
    """
    print("--- Iniciando Processo de Cálculo de Inundação ---")

    if not os.path.exists(input_dem_path):
        raise FileNotFoundError(f"Arquivo MDE de entrada não encontrado: '{input_dem_path}'")

    # --- 1. Carregar MDE e Condicionamento Hidrológico ---
    print(f"1. Carregando MDE '{input_dem_path}' e instanciando PySheds Grid...")
    grid = Grid.from_raster(input_dem_path, data_name='dem')
    dem = grid.read_raster(input_dem_path)

    print("   Condicionando MDE (fill_pits, fill_depressions, resolve_flats)...")
    pit_filled_dem = grid.fill_pits(dem)
    flooded_dem = grid.fill_depressions(pit_filled_dem)
    inflated_dem = grid.resolve_flats(flooded_dem)

    # --- 2. Direção e Acumulação de Fluxo ---
    print("2. Calculando direção e acumulação de fluxo...")
    dirmap = (64, 128, 1, 2, 4, 8, 16, 32)
    fdir = grid.flowdir(inflated_dem, dirmap=dirmap)
    acc = grid.accumulation(fdir, dirmap=dirmap)

    # --- 3. Delimitação da Bacia ---
    print(f"3. Delimitando bacia hidrográfica a partir do exutório: {outlet_coords}")
    x_outlet, y_outlet = outlet_coords

    # Máscara de rios (baseada no limiar)
    streams_mask = acc > stream_threshold

    # Snap do exutório à rede de drenagem
    try:
        x_snap, y_snap = grid.snap_to_mask(streams_mask, (x_outlet, y_outlet))
        print(f"   Exutório ajustado para: ({x_snap:.6f}, {y_snap:.6f})")
    except ValueError as e:
        print(f"Erro ao fazer snap do exutório: {e}")
        print(f"Verifique se as coordenadas estão dentro da área do MDE e próximas a um canal com acumulação > {stream_threshold}.")
        raise

    # Delimitação da Bacia
    catch = grid.catchment(x=x_snap, y=y_snap, fdir=fdir, dirmap=dirmap, xytype='coordinate')

    # Recorte do grid para a bacia (otimiza os cálculos seguintes)
    grid.clip_to(catch)
    print("   Grid recortado para a extensão da bacia.")

    # --- 4. Cálculo do HAND ---
    # O HAND deve ser calculado usando os rasters originais (não recortados),
    # mas o cálculo será feito apenas na área do grid já recortado.
    print("4. Calculando HAND (Height Above Nearest Drainage)...")
    hand = grid.compute_hand(fdir, inflated_dem, streams_mask)

    # --- 5. Geração da Mancha de Inundação ---
    print(f"5. Gerando mancha de inundação para uma profundidade de {channel_depth}m...")
    # Visualiza o HAND apenas dentro da bacia recortada
    hand_view = grid.view(hand, nodata=np.nan)
    # Calcula a profundidade da inundação onde HAND < channel_depth
    inundation_depth = np.where(hand_view < channel_depth, channel_depth - hand_view, np.nan)

    # --- 6. Salvando o Raster de Saída ---
    print(f"6. Salvando raster de inundação em '{output_tif_path}'...")
    # Cria o diretório de saída se não existir
    output_dir = os.path.dirname(output_tif_path)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    # Define o perfil do raster de saída usando as propriedades do grid recortado
    profile = {
        'crs': grid.viewfinder.crs,
        'transform': grid.viewfinder.affine,
        'height': grid.viewfinder.shape[0],
        'width': grid.viewfinder.shape[1],
        'driver': 'GTiff',
        'count': 1,
        'dtype': rasterio.float32,
        'nodata': np.nan
    }

    with rasterio.open(output_tif_path, 'w', **profile) as dst:
        dst.write(inundation_depth.astype(rasterio.float32), 1)

    print("\n--- Processo concluído com sucesso! ---")
    print(f"Resultado salvo em: {output_tif_path}")


# --- BLOCO DE EXECUÇÃO PRINCIPAL ---
if __name__ == "__main__":
    # --- CONFIGURE SEUS PARÂMETROS AQUI ---

    # 1. Caminho para o seu arquivo MDE (Modelo Digital de Elevação)
    INPUT_DEM_PATH = "srtm_data.tif"

    # 2. Caminho onde o resultado da inundação será salvo
    OUTPUT_TIF_PATH = "resultados/inundacao_hand_pure.tif"

    # 3. Coordenadas do ponto de saída (exutório) da bacia (Longitude, Latitude)
    OUTLET_COORDINATES = (-44.118627, -20.316243)

    # 4. (Opcional) Limiar de acumulação para definir o que é um rio
    STREAM_THRESHOLD = 1000

    # 5. (Opcional) Profundidade do canal em metros para simular a inundação
    CHANNEL_DEPTH_METERS = 10.0

    try:
        # Chama a função principal com os parâmetros definidos acima
        calculate_inundation(
            input_dem_path=INPUT_DEM_PATH,
            output_tif_path=OUTPUT_TIF_PATH,
            outlet_coords=OUTLET_COORDINATES,
            stream_threshold=STREAM_THRESHOLD,
            channel_depth=CHANNEL_DEPTH_METERS,
        )
    except Exception as e:
        print(f"\nERRO: Ocorreu um erro durante a execução: {e}")
        # Em um ambiente de produção, você pode querer logar o traceback completo.
        # import traceback
        # traceback.print_exc()