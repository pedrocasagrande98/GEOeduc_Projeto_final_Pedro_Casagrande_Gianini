# osm_data_downloader.py
#
# Este script executa o fluxo de trabalho para baixar dados do OpenStreetMap (OSM)
# com base em uma área de interesse (AOI) derivada de uma análise de inundação.
# O fluxo inclui:
# 1. Análise hidrológica para gerar um raster de inundação.
# 2. Definição da AOI a partir dos limites do raster de inundação.
# 3. Download de feições do OSM (edificações, vias, etc.) dentro da AOI.

# --- Bibliotecas ---
import rasterio
import geopandas as gpd
import numpy as np
from shapely.geometry import box
from pyproj import CRS
import osmnx as ox
import warnings
import os

try:
    from pysheds.grid import Grid
except ImportError:
    print("Erro: Biblioteca 'pysheds' não encontrada. Instale com 'pip install pysheds'")
    raise

# Ignorar warnings futuros
warnings.filterwarnings("ignore", category=FutureWarning)

# --- Parâmetros Globais ---
INPUT_MDE_PATH = 'srtm_data.tif'
OUTPUT_DIR = 'resultados_inundacao'
STREAM_THRESHOLD = 1000
CHANNEL_DEPTH = 10.0
OUTLET_COORDS = (-44.118627, -20.316243)

# Cria o diretório de saída
os.makedirs(OUTPUT_DIR, exist_ok=True)
print(f"Diretório de saída: '{OUTPUT_DIR}'")

# --- PARTE 1, 2 e 3: Geração do Raster de Inundação (Pré-requisito) ---
print("\n--- Iniciando Pré-requisitos: Geração do Raster de Inundação ---")
try:
    # Parte 1: Carga e condicionamento do MDE
    if not os.path.exists(INPUT_MDE_PATH):
        raise FileNotFoundError(f"Arquivo MDE '{INPUT_MDE_PATH}' não encontrado.")
    grid = Grid.from_raster(INPUT_MDE_PATH, data_name='dem')
    dem = grid.read_raster(INPUT_MDE_PATH)
    pit_filled_dem = grid.fill_pits(dem)
    flooded_dem = grid.fill_depressions(pit_filled_dem)
    inflated_dem = grid.resolve_flats(flooded_dem)
    dirmap = (64, 128, 1, 2, 4, 8, 16, 32)
    fdir = grid.flowdir(inflated_dem, dirmap=dirmap)
    acc = grid.accumulation(fdir, dirmap=dirmap)

    # Parte 2: Delimitação da bacia
    streams_mask = acc > STREAM_THRESHOLD
    x_snap, y_snap = grid.snap_to_mask(streams_mask, OUTLET_COORDS)
    catch = grid.catchment(x=x_snap, y=y_snap, fdir=fdir, dirmap=dirmap, xytype='coordinate')
    grid.clip_to(catch)

    # Parte 3: Cálculo do HAND e raster de inundação
    streams_mask_global = acc > STREAM_THRESHOLD
    hand = grid.compute_hand(fdir, inflated_dem, streams_mask_global)
    hand_view = grid.view(hand, nodata=np.nan)
    inundation_depth = np.where(hand_view < CHANNEL_DEPTH, CHANNEL_DEPTH - hand_view, np.nan)

    profile = {
        'crs': grid.viewfinder.crs,
        'transform': grid.viewfinder.affine,
        'height': grid.viewfinder.shape[0],
        'width': grid.viewfinder.shape[1],
        'driver': 'GTiff',
        'count': 1,
        'dtype': rasterio.float32,
        'nodata': np.nan
    }
    inundacao_raster_path = os.path.join(OUTPUT_DIR, 'inundacao_mapa.tif')
    with rasterio.open(inundacao_raster_path, 'w', **profile) as dst:
        dst.write(inundation_depth.astype(rasterio.float32), 1)
    print(f"Pré-requisito concluído. Raster de inundação salvo em: '{inundacao_raster_path}'")

except Exception as e:
    print(f"Erro inesperado durante a execução dos pré-requisitos: {e}")
    raise

# --- PARTE 4: Download de Dados OSM ---
print("\n--- Iniciando Parte 4: Download de Dados OSM ---")

osm_polygons_path = os.path.join(OUTPUT_DIR, 'osm_polygons.gpkg')

try:
    # Definir AOI a partir do Raster de Inundação
    print(f"Lendo raster '{inundacao_raster_path}' para definir AOI...")
    with rasterio.open(inundacao_raster_path) as src:
        flood_crs = src.crs
        flood_bounds = src.bounds

    aoi_bbox_native = box(*flood_bounds)
    aoi_gdf_native = gpd.GeoDataFrame([1], geometry=[aoi_bbox_native], crs=flood_crs)

    # Reprojetar para EPSG:4326 (necessário para OSMnx)
    target_crs_epsg = 4326
    if flood_crs.to_epsg() != target_crs_epsg:
        print(f"Reprojetando AOI para EPSG:{target_crs_epsg}...")
        aoi_gdf_4326 = aoi_gdf_native.to_crs(epsg=target_crs_epsg)
    else:
        aoi_gdf_4326 = aoi_gdf_native

    aoi_polygon_4326 = aoi_gdf_4326.geometry.iloc[0]
    print(f"AOI definida e em EPSG:{target_crs_epsg}.")

    # Coletar Dados OSM
    print("Baixando dados do OpenStreetMap (Edificações, Vias, Comodidades, etc.)...")
    tags_to_fetch = {
        'building': True,
        'highway': True,
        'amenity': True,
        'landuse': ['residential', 'commercial', 'industrial', 'retail'],
        'natural': ['water'],
        'leisure': ['park', 'playground']
    }
    osm_features_gdf = ox.features_from_polygon(aoi_polygon_4326, tags_to_fetch)
    print(f"Download concluído. {len(osm_features_gdf)} feições encontradas.")

    # Filtrar apenas Polígonos
    osm_polygons_gdf = osm_features_gdf[
        osm_features_gdf.geometry.notna() &
        osm_features_gdf.geometry.type.isin(['Polygon', 'MultiPolygon'])
    ].copy()
    print(f"Filtrado para {len(osm_polygons_gdf)} feições do tipo Polígono/Multipolígono.")

    # Salvar os Polígonos
    if osm_polygons_gdf.empty:
        print("Aviso: Nenhuma feição poligonal encontrada na AOI para as tags selecionadas.")
    else:
        if osm_polygons_gdf.crs is None:
             osm_polygons_gdf.crs = CRS.from_epsg(target_crs_epsg)
        osm_polygons_gdf.to_file(osm_polygons_path, driver="GPKG")
        print(f"Parte 4 concluída com sucesso!")
        print(f"Feições poligonais salvas em: '{osm_polygons_path}'")

except Exception as e:
    print(f"Erro inesperado na Parte 4: {e}")
    raise
