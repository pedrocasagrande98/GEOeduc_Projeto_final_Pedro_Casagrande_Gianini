### =-=-=-=-= não apagar streamlit run HOME.py =-=-=-=- ##
import streamlit as st

st.set_page_config(
    page_title="Análise Hidrográfica Integrada",
    page_icon="🌿",
    layout="wide"
)

st.title("🌿 Análise Hidrográfica Integrada 🛰️")
st.markdown("---")
st.markdown("Bem-vindo à Análise Hidrográfica Integrada! Esta aplicação utiliza dados geoespaciais para fornecer insights sobre bacias hidrográficas, redes de drenagem e muito mais.")
st.markdown("### Como usar:")
st.info("""
1.  **Navegue para a página desejada no menu lateral.**
2.  **Na página escolhida, siga as instruções para fazer upload de arquivos ou inserir as informações necessárias.**
3.  **Aguarde a análise e explore os resultados na área de conteúdo principal.**
""")
st.markdown("---")
st.image("https://i.imgur.com/rztB5pr.png", caption="Visualização da Bacia Hidrográfica e Rede de Drenagem")

st.markdown("""
    <style>
    html, body, [class*="st-"] {
        font-size: 1.1rem;
    }
    </style>
""", unsafe_allow_html=True)
