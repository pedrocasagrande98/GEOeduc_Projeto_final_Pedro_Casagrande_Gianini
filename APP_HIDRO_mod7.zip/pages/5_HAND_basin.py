import streamlit as st
import os
import numpy as np
import rasterio
from pysheds.grid import Grid
import tempfile
import hashlib
import json
from rasterio.features import shapes

st.set_page_config(layout="wide")

st.title("🌊 Cálculo de Mancha de Inundação com HAND (Bacia Específica)")

st.markdown(
    """
    Esta página permite calcular a mancha de inundação
    para uma bacia hidrográfica específica, a partir de um Modelo Digital de Elevação (MDE)
    e um ponto de exutório, usando o método HAND (Height Above Nearest Drainage).
    O resultado será salvo como GeoTIFF e GeoJSON.
    """
)

# --- Função de Cálculo HAND para Bacia (adaptada do script original) ---
def calculate_inundation_for_basin(
    input_dem_path: str,
    output_inundation_path: str,
    output_geojson_path: str,
    outlet_coords: tuple,
    stream_threshold: int = 1000,
    channel_depth: float = 10.0,
):
    """
    Executa o fluxo completo de cálculo de inundação a partir de um MDE
    para uma bacia hidrográfica delimitada por um ponto de exutório.

    Args:
        input_dem_path (str): Caminho para o arquivo MDE de entrada (GeoTIFF).
        output_inundation_path (str): Caminho para salvar o raster de inundação de saída (GeoTIFF).
        output_geojson_path (str): Caminho para salvar o GeoJSON da mancha de inundação.
        outlet_coords (tuple): Tupla com as coordenadas (longitude, latitude) do exutório.
        stream_threshold (int): Limiar de acumulação para definir a rede de drenagem.
        channel_depth (float): Profundidade do canal em metros para simular a inundação.
    """
    st.info(f"Iniciando Processo de Cálculo de Inundação (Bacia) para {os.path.basename(input_dem_path)}...")

    if not os.path.exists(input_dem_path):
        st.error(f"Arquivo MDE de entrada não encontrado: '{input_dem_path}'")
        return None, None

    # --- 1. Carregar MDE e Condicionamento Hidrológico ---
    st.write("1. Carregando MDE e instanciando PySheds Grid...")
    try:
        grid = Grid.from_raster(input_dem_path, data_name='dem')
        dem = grid.read_raster(input_dem_path)
    except Exception as e:
        st.error(f"Erro ao carregar o MDE com PySheds. Verifique o formato do arquivo GeoTIFF: {e}")
        return None, None

    st.write("   Condicionando MDE (fill_pits, fill_depressions, resolve_flats)...")
    pit_filled_dem = grid.fill_pits(dem)
    flooded_dem = grid.fill_depressions(pit_filled_dem)
    inflated_dem = grid.resolve_flats(flooded_dem)

    # --- 2. Direção e Acumulação de Fluxo ---
    st.write("2. Calculando direção e acumulação de fluxo...")
    dirmap = (64, 128, 1, 2, 4, 8, 16, 32)
    fdir = grid.flowdir(inflated_dem, dirmap=dirmap)
    acc = grid.accumulation(fdir, dirmap=dirmap)

    # --- 3. Delimitação da Bacia ---
    st.write(f"3. Delimitando bacia hidrográfica a partir do exutório: {outlet_coords}")
    x_outlet, y_outlet = outlet_coords

    # Máscara de rios (baseada no limiar)
    streams_mask = acc > stream_threshold

    # Snap do exutório à rede de drenagem
    try:
        x_snap, y_snap = grid.snap_to_mask(streams_mask, (x_outlet, y_outlet))
        st.write(f"   Exutório ajustado para: ({x_snap:.6f}, {y_snap:.6f})")
    except ValueError as e:
        st.error(f"Erro ao fazer snap do exutório: {e}")
        st.error(f"Verifique se as coordenadas estão dentro da área do MDE e próximas a um canal com acumulação > {stream_threshold}.")
        return None, None

    # Delimitação da Bacia
    catch = grid.catchment(x=x_snap, y=y_snap, fdir=fdir, dirmap=dirmap, xytype='coordinate')

    # Recorte do grid para a bacia (otimiza os cálculos seguintes)
    grid.clip_to(catch)
    st.write("   Grid recortado para a extensão da bacia.")

    # --- 4. Cálculo do HAND ---
    st.write("4. Calculando HAND (Height Above Nearest Drainage)...")
    hand = grid.compute_hand(fdir, inflated_dem, streams_mask)

    # --- 5. Geração da Mancha de Inundação ---
    st.write(f"5. Gerando mancha de inundação para uma profundidade de {channel_depth}m...")
    hand_view = grid.view(hand, nodata=np.nan)
    inundation_depth = np.where(hand_view < channel_depth, channel_depth - hand_view, np.nan)

    # --- 6. Salvando os Rasters de Saída e GeoJSON ---
    output_dir = os.path.dirname(output_inundation_path)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    profile = {
        'crs': grid.viewfinder.crs,
        'transform': grid.viewfinder.affine,
        'height': grid.viewfinder.shape[0],
        'width': grid.viewfinder.shape[1],
        'driver': 'GTiff',
        'count': 1,
        'dtype': rasterio.float32,
        'nodata': np.nan
    }

    st.write(f"6. Salvando raster de inundação em '{output_inundation_path}'...")
    with rasterio.open(output_inundation_path, 'w', **profile) as dst:
        dst.write(inundation_depth.astype(rasterio.float32), 1)

    # --- GeoJSON Conversion ---
    st.write(f"   Gerando e salvando GeoJSON da mancha de inundação em '{output_geojson_path}'...")
    try:
        # Create a binary mask for inundated areas (where depth > 0 and not NaN)
        inundated_mask = (inundation_depth > 0) & (~np.isnan(inundation_depth))

        geometries = []
        # Use the profile's transform for vectorization
        for geom, val in shapes(inundated_mask.astype(np.int16), transform=profile['transform']):
            if val == 1: # Only include inundated areas
                geometries.append({
                    "type": "Feature",
                    "geometry": geom,
                    "properties": {"inundated": True}
                })

        geojson_output = {
            "type": "FeatureCollection",
            "features": geometries
        }

        with open(output_geojson_path, 'w') as f:
            json.dump(geojson_output, f)
    except Exception as e:
        st.error(f"Erro ao gerar ou salvar o arquivo GeoJSON: {e}")
        # If GeoJSON generation fails, return None for its path
        return output_inundation_path, None

    st.success(f"Processo concluído com sucesso! Resultados salvos em: {output_dir}")
    return output_inundation_path, output_geojson_path

# --- Interface Streamlit ---

# Initialize session state variables if they don't exist
if "dem_file_path" not in st.session_state:
    st.session_state.dem_file_path = None
if "uploaded_file_hash" not in st.session_state:
    st.session_state.uploaded_file_hash = None
if "output_inundation_path" not in st.session_state:
    st.session_state.output_inundation_path = None
if "output_geojson_path" not in st.session_state:
    st.session_state.output_geojson_path = None

uploaded_file = st.file_uploader("Faça upload do seu arquivo MDE (GeoTIFF)", type=["tif", "tiff"])

input_dem_path = None # Initialize input_dem_path for the current rerun

if uploaded_file is not None:
    st.success("Arquivo MDE carregado com sucesso!")

    # Generate a hash for the current uploaded file content to detect changes
    current_file_hash = hashlib.md5(uploaded_file.getvalue()).hexdigest()

    # Check if a new file has been uploaded or if the content has changed
    if st.session_state.uploaded_file_hash != current_file_hash:
        # A new or different file has been uploaded
        # Clean up previous temporary DEM if it exists
        if st.session_state.dem_file_path and os.path.exists(st.session_state.dem_file_path):
            try:
                os.remove(st.session_state.dem_file_path)
                st.session_state.dem_file_path = None
            except OSError as e:
                st.warning(f"Não foi possível remover o arquivo temporário anterior: {e}")

        # Save the new uploaded file to a temporary location
        fd, temp_path = tempfile.mkstemp(suffix=".tif")
        os.close(fd) # Close the file descriptor immediately

        with open(temp_path, "wb") as f:
            f.write(uploaded_file.getvalue())
        
        st.session_state.dem_file_path = temp_path
        st.session_state.uploaded_file_hash = current_file_hash
        # Reset output paths when a new DEM is uploaded
        st.session_state.output_inundation_path = None
        st.session_state.output_geojson_path = None
    
    input_dem_path = st.session_state.dem_file_path
    
    st.sidebar.header("Parâmetros de Análise HAND e Bacia")
    
    st.sidebar.subheader("Coordenadas do Exutório")
    col1, col2 = st.sidebar.columns(2)
    outlet_lon = col1.number_input(
        "Longitude do Exutório",
        min_value=-180.0,
        max_value=180.0,
        value=-44.118627,
        step=0.000001,
        format="%.6f",
        key="outlet_lon"
    )
    outlet_lat = col2.number_input(
        "Latitude do Exutório",
        min_value=-90.0,
        max_value=90.0,
        value=-20.316243,
        step=0.000001,
        format="%.6f",
        key="outlet_lat"
    )
    outlet_coords = (outlet_lon, outlet_lat)

    stream_threshold = st.sidebar.number_input(
        "Limiar de Acumulação (Stream Threshold)",
        min_value=100,
        max_value=100000,
        value=1000,
        step=100,
        help="Define o que é considerado um rio. Valores menores = mais rios; valores maiores = apenas rios principais.",
        key="stream_threshold"
    )
    channel_depth = st.sidebar.number_input(
        "Profundidade do Canal (metros)",
        min_value=0.1,
        max_value=100.0,
        value=10.0,
        step=0.5,
        help="Altura da água acima do fundo do canal para simular a inundação.",
        key="channel_depth"
    )

    if st.button("Executar Cálculo HAND para Bacia"):
        if input_dem_path is None or not os.path.exists(input_dem_path):
            st.error("Erro: O arquivo MDE não está disponível para processamento. Por favor, recarregue o arquivo.")
        else:
            with st.spinner("Calculando mancha de inundação e gerando GeoJSON... Isso pode levar alguns minutos."):
                try:
                    # Define o diretório de saída e cria-o se não existir
                    output_dir = "resultado/mod5"
                    os.makedirs(output_dir, exist_ok=True)
                    
                    # Constrói os caminhos completos para os arquivos de saída
                    base_filename = os.path.splitext(uploaded_file.name)[0]
                    output_inundation_filename = f"inundacao_hand_basin_{base_filename}.tif"
                    output_geojson_filename = f"inundacao_hand_basin_{base_filename}.geojson"
                    
                    output_inundation_path = os.path.join(output_dir, output_inundation_filename)
                    output_geojson_path = os.path.join(output_dir, output_geojson_filename)

                    result_inundation_path, result_geojson_path = calculate_inundation_for_basin(
                        input_dem_path=input_dem_path,
                        output_inundation_path=output_inundation_path,
                        output_geojson_path=output_geojson_path,
                        outlet_coords=outlet_coords,
                        stream_threshold=stream_threshold,
                        channel_depth=channel_depth,
                    )
                    
                    st.session_state.output_inundation_path = result_inundation_path
                    st.session_state.output_geojson_path = result_geojson_path

                except Exception as e:
                    st.error(f"Ocorreu um erro durante a execução do cálculo HAND para a bacia: {e}")
                    # Clear output paths if an error occurred during calculation
                    st.session_state.output_inundation_path = None
                    st.session_state.output_geojson_path = None
                finally:
                    # The cleanup is handled by the 'if uploaded_file is not None' block when a new file is uploaded or on app reset.
                    pass
    
    # Display download buttons if results are available in session state
    if st.session_state.output_inundation_path and os.path.exists(st.session_state.output_inundation_path) and \
       st.session_state.output_geojson_path and os.path.exists(st.session_state.output_geojson_path):
        st.subheader("Resultados:")
        output_dir = "resultado/mod5" # Redefine output_dir for display
        st.success(f"Cálculo concluído! Os arquivos foram salvos em: {output_dir}") # Re-display success message
        
        st.markdown("---") # Separator
        st.write("Seus downloads estão prontos. Por favor, clique nos botões abaixo para baixar os arquivos.")
        
        # Re-derive filenames for download buttons as they might not be in session state directly
        base_filename = os.path.splitext(uploaded_file.name)[0]
        output_inundation_filename = f"inundacao_hand_basin_{base_filename}.tif"
        output_geojson_filename = f"inundacao_hand_basin_{base_filename}.geojson"

        with open(st.session_state.output_inundation_path, "rb") as f:
            st.download_button(
                label="Baixar Mancha de Inundação (GeoTIFF)",
                data=f.read(),
                file_name=output_inundation_filename,
                mime="application/octet-stream"
            )
        
        with open(st.session_state.output_geojson_path, "r") as f:
            st.download_button(
                label="Baixar Mancha de Inundação (GeoJSON)",
                data=f.read(),
                file_name=output_geojson_filename,
                mime="application/geo+json"
            )
        
        st.info("Para visualizar os resultados diretamente aqui, você precisaria de uma biblioteca de mapeamento (e.g., folium, kepler.gl) e talvez converter os GeoTIFFs para um formato web-friendly (e.g., PNG, GeoJSON).")

else:
    st.info("Por favor, faça o upload de um arquivo MDE (GeoTIFF) e defina as coordenadas do exutório para começar.")
    # Clean up any temporary DEM file if no file is uploaded or app is reset
    if st.session_state.dem_file_path and os.path.exists(st.session_state.dem_file_path):
        try:
            os.remove(st.session_state.dem_file_path)
            st.session_state.dem_file_path = None
        except OSError as e:
            st.warning(f"Não foi possível remover o arquivo temporário no reset da página: {e}")
    st.session_state.uploaded_file_hash = None # Reset hash
    st.session_state.output_inundation_path = None
    st.session_state.output_geojson_path = None
