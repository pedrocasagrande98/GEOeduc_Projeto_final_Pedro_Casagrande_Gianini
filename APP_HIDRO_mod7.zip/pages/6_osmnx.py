import streamlit as st
import geopandas as gpd
import os
from pyproj import CRS
import osmnx as ox
import warnings
import tempfile
import hashlib
import json
from shapely.geometry import box # Importar box para definir AOI a partir de bounds

# Ignorar warnings futuros do geopandas/fiona
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", message=".*CRS mismatch between the CRS of the first layer and the CRS of the GeoDataFrame.*")

st.set_page_config(layout="wide")

st.title("⬇️ Download de Dados OpenStreetMap (OSMnx)")

st.markdown(
    """
    Esta página permite baixar dados do OpenStreetMap (OSM) para uma Área de Interesse (AOI)
    específica, definida por um arquivo GeoJSON ou GPKG. Você pode especificar quais tipos
    de feições OSM (tags) deseja baixar.
    """
)

# --- Função para baixar dados OSM ---
def download_osm_data(
    aoi_file_path: str,
    tags_to_fetch_dict: dict,
    output_gpkg_path: str,
):
    """
    Baixa dados do OpenStreetMap para uma AOI e tags especificadas.

    Args:
        aoi_file_path (str): Caminho para o arquivo GeoJSON/GPKG que define a AOI.
        tags_to_fetch_dict (dict): Dicionário de tags OSM para buscar (ex: {'building': True}).
        output_gpkg_path (str): Caminho para salvar o GeoPackage de saída com os dados OSM.

    Returns:
        str: Caminho para o arquivo GPKG de saída se o download for bem-sucedido, None caso contrário.
    """
    st.info("Iniciando download de dados OSM...")

    # --- Carregar AOI ---
    aoi_gdf = gpd.GeoDataFrame(geometry=[], crs=CRS.from_epsg(4326)) # Default CRS
    if os.path.exists(aoi_file_path):
        try:
            st.write(f"1. Carregando AOI de '{os.path.basename(aoi_file_path)}'...")
            aoi_gdf = gpd.read_file(aoi_file_path)
            if aoi_gdf.empty:
                st.error("O arquivo AOI carregado está vazio.")
                return None
            
            # Dissolver para garantir uma única geometria para a AOI
            # Verifica se a coluna 'temp_id' existe antes de tentar dissolver por ela
            if len(aoi_gdf) > 1:
                st.write("   AOI contém múltiplas feições. Dissolvendo para uma única geometria...")
                # Se não houver coluna para dissolver, cria uma temporária
                if 'temp_dissolve_id' not in aoi_gdf.columns:
                    aoi_gdf['temp_dissolve_id'] = 1
                aoi_gdf = aoi_gdf.dissolve(by='temp_dissolve_id')
            
            st.write(f"   AOI carregada (CRS: {aoi_gdf.crs}).")
        except Exception as e:
            st.error(f"Erro ao carregar o arquivo AOI: {e}")
            return None
    else:
        st.error(f"Erro: Arquivo AOI '{os.path.basename(aoi_file_path)}' não encontrado.")
        return None

    # Reprojetar AOI para EPSG:4326 (WGS84) se necessário, pois OSMnx espera isso
    target_crs_epsg = 4326
    if aoi_gdf.crs is None:
        st.warning(f"CRS da AOI não definido. Assumindo EPSG:{target_crs_epsg}. Por favor, verifique se está correto.")
        aoi_gdf.crs = CRS.from_epsg(target_crs_epsg)
    elif aoi_gdf.crs.to_epsg() != target_crs_epsg:
        st.write(f"   Reprojetando AOI de {aoi_gdf.crs} para EPSG:{target_crs_epsg}...")
        aoi_gdf = aoi_gdf.to_crs(epsg=target_crs_epsg)
    else:
        st.write("   CRS da AOI já é compatível com OSMnx (EPSG:4326).")

    aoi_polygon = aoi_gdf.geometry.iloc[0] # Pega a primeira (e única após dissolve) geometria

    # --- Coletar Dados OSM ---
    st.write("2. Baixando dados do OpenStreetMap com as tags especificadas...")
    st.write("   (DEBUG: ox.config() não está sendo chamado neste script.)") # Mensagem de depuração
    try:
        # Removido ox.config() para compatibilidade com versões mais antigas ou ambientes específicos
        osm_features_gdf = ox.features_from_polygon(aoi_polygon, tags_to_fetch_dict)
        st.write(f"   Download concluído. {len(osm_features_gdf)} feições encontradas.")
    except Exception as e:
        st.error(f"Erro ao baixar dados do OpenStreetMap: {e}")
        st.error("Verifique as tags OSM e a conectividade com a internet. Para grandes áreas, considere dividir a AOI.")
        return None

    # --- Filtrar apenas Polígonos (se houver) ---
    st.write("3. Filtrando feições para manter apenas polígonos/multipolígonos...")
    osm_polygons_gdf = osm_features_gdf[
        osm_features_gdf.geometry.notna() &
        osm_features_gdf.geometry.type.isin(['Polygon', 'MultiPolygon'])
    ].copy()
    st.write(f"   Filtrado para {len(osm_polygons_gdf)} feições do tipo Polígono/Multipolígono.")

    # --- Salvando os Polígonos ---
    if osm_polygons_gdf.empty:
        st.warning("Nenhuma feição poligonal encontrada na AOI para as tags selecionadas. Nenhum arquivo de saída será gerado.")
        return None
    else:
        output_dir = os.path.dirname(output_gpkg_path)
        os.makedirs(output_dir, exist_ok=True)
        try:
            st.write(f"4. Salvando dados OSM poligonais em '{os.path.basename(output_gpkg_path)}'...")
            # Garante que o CRS esteja definido antes de salvar
            if osm_polygons_gdf.crs is None:
                osm_polygons_gdf.crs = CRS.from_epsg(target_crs_epsg)
            osm_polygons_gdf.to_file(output_gpkg_path, driver="GPKG")
            st.success(f"Download e salvamento concluídos com sucesso! Resultado salvo em: {output_gpkg_path}")
            return output_gpkg_path
        except Exception as e:
            st.error(f"Erro ao salvar o arquivo GPKG de saída: {e}")
            return None


# --- Interface Streamlit ---

# Initialize session state variables for file paths and hashes
if "aoi_file_path" not in st.session_state:
    st.session_state.aoi_file_path = None
if "aoi_file_hash" not in st.session_state:
    st.session_state.aoi_file_hash = None
if "output_osmnx_download_path" not in st.session_state:
    st.session_state.output_osmnx_download_path = None


st.sidebar.header("Configurações de Download OSM")

uploaded_aoi_file = st.sidebar.file_uploader(
    "1. Faça upload do arquivo da Área de Interesse (AOI) (GeoJSON/GPKG)",
    type=["geojson", "gpkg"],
    key="aoi_uploader"
)

default_tags = {
    'building': True,
    'highway': True,
    'amenity': True,
    'landuse': ['residential', 'commercial', 'industrial', 'retail'],
    'natural': ['wood', 'grassland'],
    'leisure': ['park', 'playground', 'stadium']
}

tags_input = st.sidebar.text_area(
    "2. Tags OSM para baixar (formato JSON)",
    value=json.dumps(default_tags, indent=2),
    height=200,
    help="Defina as tags OSM no formato JSON. Ex: {'building': True, 'highway': 'residential'}"
)

tags_to_fetch = {}
try:
    tags_to_fetch = json.loads(tags_input)
except json.JSONDecodeError:
    st.sidebar.error("Erro no formato JSON das tags. Por favor, corrija.")
    tags_to_fetch = None # Prevent execution with invalid tags


# --- Handle AOI File Upload ---
if uploaded_aoi_file is not None:
    current_aoi_hash = hashlib.md5(uploaded_aoi_file.getvalue()).hexdigest()
    if st.session_state.aoi_file_hash != current_aoi_hash:
        if st.session_state.aoi_file_path and os.path.exists(st.session_state.aoi_file_path):
            os.remove(st.session_state.aoi_file_path)
        suffix = os.path.splitext(uploaded_aoi_file.name)[1]
        fd, temp_path = tempfile.mkstemp(suffix=suffix)
        os.close(fd)
        with open(temp_path, "wb") as f:
            f.write(uploaded_aoi_file.getvalue())
        st.session_state.aoi_file_path = temp_path
        st.session_state.aoi_file_hash = current_aoi_hash
        st.session_state.output_osmnx_download_path = None # Reset output on new input
    st.sidebar.success(f"Arquivo AOI carregado: {uploaded_aoi_file.name}")


# --- Execution Button ---
if st.button("Iniciar Download de Dados OSM"):
    if st.session_state.aoi_file_path and tags_to_fetch:
        with st.spinner("Baixando e processando dados OSM... Isso pode levar alguns minutos para grandes áreas."):
            try:
                output_dir = "resultado/mod6"
                os.makedirs(output_dir, exist_ok=True)

                # Construct output filename based on input AOI filename
                aoi_base = os.path.splitext(os.path.basename(uploaded_aoi_file.name))[0]
                output_filename = f"osm_polygons_aoi_{aoi_base}.gpkg"
                output_gpkg_path = os.path.join(output_dir, output_filename)

                result_path = download_osm_data(
                    aoi_file_path=st.session_state.aoi_file_path,
                    tags_to_fetch_dict=tags_to_fetch,
                    output_gpkg_path=output_gpkg_path,
                )

                st.session_state.output_osmnx_download_path = result_path

            except Exception as e:
                st.error(f"Ocorreu um erro durante o download de dados OSM: {e}")
                st.session_state.output_osmnx_download_path = None
            finally:
                # Clean up temporary AOI input file after analysis attempt
                if st.session_state.aoi_file_path and os.path.exists(st.session_state.aoi_file_path):
                    os.remove(st.session_state.aoi_file_path)
                    st.session_state.aoi_file_path = None
                    st.session_state.aoi_file_hash = None
    else:
        st.warning("Por favor, faça upload do arquivo AOI e defina as tags OSM para iniciar o download.")

# --- Download Button for Results ---
if st.session_state.output_osmnx_download_path and os.path.exists(st.session_state.output_osmnx_download_path):
    st.subheader("Download do Resultado:")
    output_filename = os.path.basename(st.session_state.output_osmnx_download_path)
    with open(st.session_state.output_osmnx_download_path, "rb") as f:
        st.download_button(
            label="Baixar Dados OSM (GeoPackage)",
            data=f.read(),
            file_name=output_filename,
            mime="application/octet-stream"
        )
    st.info(f"O arquivo de resultado foi salvo em: {st.session_state.output_osmnx_download_path}")

# --- Cleanup on app reset/no files uploaded ---
if uploaded_aoi_file is None:
    if st.session_state.aoi_file_path and os.path.exists(st.session_state.aoi_file_path):
        os.remove(st.session_state.aoi_file_path)
        st.session_state.aoi_file_path = None
        st.session_state.aoi_file_hash = None
    st.session_state.output_osmnx_download_path = None
