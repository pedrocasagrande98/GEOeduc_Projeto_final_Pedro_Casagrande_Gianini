import streamlit as st
import geopandas as gpd
import os
import numpy as np
from pyproj import CRS
import warnings
import tempfile
import hashlib

# Ignorar warnings futuros do geopandas/fiona
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", message=".*CRS mismatch between the CRS of the first layer and the CRS of the GeoDataFrame.*")

st.set_page_config(layout="wide")

st.title("📊 Análise Estatística de Interseção")

st.markdown(
    """
    Esta página permite realizar uma análise de interseção espacial entre uma camada vetorial
    de inundação (GeoJSON/GPKG) e polígonos do OpenStreetMap (GeoJSON/GPKG).
    O objetivo é identificar quais polígonos OSM são afetados pela área de inundação e gerar estatísticas.
    Assume-se que os polígonos OSM de entrada já foram pré-filtrados (e.g., sem feições de 'water').
    """
)

# --- Função para realizar a análise OSMnx ---
def perform_osmnx_analysis(
    flood_vector_path: str,
    osm_polygons_path: str,
    output_gpkg_path: str,
):
    """
    Executa a análise de interseção entre o vetor de inundação e os polígonos OSM.

    Args:
        flood_vector_path (str): Caminho para o arquivo vetorial de inundação (GeoJSON/GPKG).
        osm_polygons_path (str): Caminho para o arquivo de polígonos OSM (GeoJSON/GPKG).
        output_gpkg_path (str): Caminho para salvar o GeoPackage de saída com os polígonos afetados.

    Returns:
        str: Caminho para o arquivo GPKG de saída se a análise for bem-sucedida, None caso contrário.
    """
    st.info("Iniciando Análise de Interseção (Inundação vs Polígonos OSM)...")

    # --- Carregar Vetor de Inundação ---
    flood_analysis_gdf = gpd.GeoDataFrame(geometry=[], crs=CRS.from_epsg(4326)) # Default CRS
    if os.path.exists(flood_vector_path):
        try:
            st.write(f"1. Carregando vetor de inundação '{os.path.basename(flood_vector_path)}'...")
            flood_analysis_gdf = gpd.read_file(flood_vector_path)
            if flood_analysis_gdf.empty:
                st.warning("Vetor de inundação carregado está vazio.")
            else:
                if len(flood_analysis_gdf) > 1:
                    st.write("   Vetor de inundação contém múltiplas feições. Dissolvendo para uma única...")
                    # Ensure 'temp_id' column exists before dissolving
                    if 'temp_id' not in flood_analysis_gdf.columns:
                        flood_analysis_gdf['temp_id'] = 1
                    flood_analysis_gdf = flood_analysis_gdf.dissolve(by='temp_id')
                st.write(f"   Vetor de inundação carregado (CRS: {flood_analysis_gdf.crs}).")
        except Exception as e:
            st.error(f"Erro ao carregar o vetor de inundação: {e}")
            return None
    else:
        st.error(f"Erro: Arquivo vetorial de inundação '{os.path.basename(flood_vector_path)}' não encontrado.")
        return None

    # --- Carregar Polígonos OSM e Harmonizar CRS ---
    osm_polygons_gdf_input = gpd.GeoDataFrame(geometry=[], crs=CRS.from_epsg(4326)) # Default CRS
    if os.path.exists(osm_polygons_path):
        try:
            st.write(f"2. Carregando vetor de polígonos OSM '{os.path.basename(osm_polygons_path)}'...")
            osm_polygons_gdf_input = gpd.read_file(osm_polygons_path)
            if osm_polygons_gdf_input.empty:
                st.warning("Vetor de polígonos OSM carregado está vazio.")
            else:
                st.write(f"   Vetor de polígonos OSM carregado (CRS: {osm_polygons_gdf_input.crs}).")
        except Exception as e:
            st.error(f"Erro ao carregar o vetor de polígonos OSM: {e}")
            return None
    else:
        st.error(f"Erro: Arquivo de polígonos OSM '{os.path.basename(osm_polygons_path)}' não encontrado.")
        return None

    # Determinar o CRS alvo para harmonização
    target_crs = None
    if not flood_analysis_gdf.empty and flood_analysis_gdf.crs:
        target_crs = flood_analysis_gdf.crs
    elif not osm_polygons_gdf_input.empty and osm_polygons_gdf_input.crs:
        target_crs = osm_polygons_gdf_input.crs
    else:
        st.error("Erro: Não foi possível determinar um CRS alvo para harmonização. Ambos os GeoDataFrames estão vazios ou sem CRS.")
        return None

    osm_polygons_gdf = osm_polygons_gdf_input
    if osm_polygons_gdf_input.crs != target_crs:
        st.write(f"   Reprojetando polígonos OSM de {osm_polygons_gdf_input.crs} para {target_crs}...")
        osm_polygons_gdf = osm_polygons_gdf_input.to_crs(target_crs)
    else:
        st.write("   CRS dos polígonos OSM e inundação são compatíveis ou já harmonizados.")

    # --- Filtragem de polígonos de 'water' REMOVIDA (assumindo pré-filtragem no módulo de download) ---
    st.write(f"3. Total de polígonos OSM para análise (assumindo pré-filtragem de 'water'): {len(osm_polygons_gdf)}")

    # --- Análise de Interseção ---
    st.write("4. Realizando interseção espacial (Inundação vs Polígonos OSM)...")
    affected_polygons_gdf = gpd.GeoDataFrame(geometry=[], crs=target_crs)

    if not osm_polygons_gdf.empty and not flood_analysis_gdf.empty:
        if osm_polygons_gdf.crs != flood_analysis_gdf.crs:
            st.error(f"Erro: CRS não coincidem ({osm_polygons_gdf.crs} vs {flood_analysis_gdf.crs}). Interseção não realizada.")
            return None
        else:
            try:
                affected_sjoin = gpd.sjoin(osm_polygons_gdf, flood_analysis_gdf, how='inner', predicate='intersects')
                # Remove duplicatas de índice que podem surgir do sjoin se um polígono OSM intersecta múltiplas partes do polígono de inundação
                affected_polygons_gdf = affected_sjoin[~affected_sjoin.index.duplicated(keep='first')]
                st.write(f"   {len(affected_polygons_gdf)} polígonos OSM intersectam a área de inundação.")
            except Exception as e:
                st.error(f"Erro durante a operação de interseção espacial: {e}")
                return None
    else:
        st.warning("Não há dados de polígonos OSM (pós-filter) ou inundação para realizar a interseção.")

    # --- Estatísticas ---
    count_affected_polygons = len(affected_polygons_gdf)
    total_polygons_aoi = len(osm_polygons_gdf)

    st.subheader("Estatísticas da Análise de Impacto (Polígonos OSM):")
    st.write(f"Número total de polígonos OSM na AOI (assumindo pré-filtragem de 'water'): **{total_polygons_aoi}**")
    st.write(f"Número de polígonos OSM afetados pela inundação: **{count_affected_polygons}**")
    if total_polygons_aoi > 0:
        percent_affected = (count_affected_polygons / total_polygons_aoi) * 100
        st.write(f"Percentual de polígonos OSM afetados: **{percent_affected:.2f}%**")
    else:
        st.write(f"Percentual de polígonos OSM afetados: N/A (nenhum polígono OSM na AOI)")

    # --- Salvando o Resultado ---
    if not affected_polygons_gdf.empty:
        output_dir = os.path.dirname(output_gpkg_path)
        os.makedirs(output_dir, exist_ok=True)
        try:
            st.write(f"5. Salvando polígonos afetados em '{os.path.basename(output_gpkg_path)}'...")
            affected_polygons_gdf.to_file(output_gpkg_path, driver="GPKG")
            st.success(f"Análise Concluída com Sucesso! Resultado salvo em: {output_gpkg_path}")
            return output_gpkg_path
        except Exception as e:
            st.error(f"Erro ao salvar o arquivo GPKG de saída: {e}")
            return None
    else:
        st.warning("Nenhum polígono OSM foi afetado pela inundação. Nenhum arquivo de saída será gerado.")
        return None


# --- Interface Streamlit ---

# Initialize session state variables for file paths and hashes
if "flood_file_path" not in st.session_state:
    st.session_state.flood_file_path = None
if "flood_file_hash" not in st.session_state:
    st.session_state.flood_file_hash = None
if "osm_file_path" not in st.session_state:
    st.session_state.osm_file_path = None
if "osm_file_hash" not in st.session_state:
    st.session_state.osm_file_hash = None
if "output_statistics_path" not in st.session_state:
    st.session_state.output_statistics_path = None


st.sidebar.header("Upload de Arquivos")

uploaded_flood_file = st.sidebar.file_uploader(
    "1. Faça upload do vetor de inundação (GeoJSON/GPKG)",
    type=["geojson", "gpkg"],
    key="flood_uploader"
)
uploaded_osm_file = st.sidebar.file_uploader(
    "2. Faça upload dos polígonos OSM (GeoJSON/GPKG) (pré-filtrados de 'water')",
    type=["geojson", "gpkg"],
    key="osm_uploader"
)

# --- Handle Flood File Upload ---
if uploaded_flood_file is not None:
    current_flood_hash = hashlib.md5(uploaded_flood_file.getvalue()).hexdigest()
    if st.session_state.flood_file_hash != current_flood_hash:
        if st.session_state.flood_file_path and os.path.exists(st.session_state.flood_file_path):
            os.remove(st.session_state.flood_file_path)
        suffix = os.path.splitext(uploaded_flood_file.name)[1]
        fd, temp_path = tempfile.mkstemp(suffix=suffix)
        os.close(fd)
        with open(temp_path, "wb") as f:
            f.write(uploaded_flood_file.getvalue())
        st.session_state.flood_file_path = temp_path
        st.session_state.flood_file_hash = current_flood_hash
        st.session_state.output_statistics_path = None # Reset output on new input
    st.sidebar.success(f"Vetor de inundação carregado: {uploaded_flood_file.name}")

# --- Handle OSM File Upload ---
if uploaded_osm_file is not None:
    current_osm_hash = hashlib.md5(uploaded_osm_file.getvalue()).hexdigest()
    if st.session_state.osm_file_hash != current_osm_hash:
        if st.session_state.osm_file_path and os.path.exists(st.session_state.osm_file_path):
            os.remove(st.session_state.osm_file_path)
        suffix = os.path.splitext(uploaded_osm_file.name)[1]
        fd, temp_path = tempfile.mkstemp(suffix=suffix)
        os.close(fd)
        with open(temp_path, "wb") as f:
            f.write(uploaded_osm_file.getvalue())
        st.session_state.osm_file_path = temp_path
        st.session_state.osm_file_hash = current_osm_hash
        st.session_state.output_statistics_path = None # Reset output on new input
    st.sidebar.success(f"Polígonos OSM carregados: {uploaded_osm_file.name}")


# --- Execution Button ---
if st.button("Executar Análise de Interseção"):
    if st.session_state.flood_file_path and st.session_state.osm_file_path:
        with st.spinner("Realizando análise de interseção... Isso pode levar alguns minutos."):
            try:
                output_dir = "resultado/mod7" # Changed output directory to mod7
                os.makedirs(output_dir, exist_ok=True)

                # Construct output filename based on input filenames
                flood_base = os.path.splitext(os.path.basename(uploaded_flood_file.name))[0]
                osm_base = os.path.splitext(os.path.basename(uploaded_osm_file.name))[0]
                output_filename = f"statistics_affected_{flood_base}_vs_{osm_base}.gpkg"
                output_gpkg_path = os.path.join(output_dir, output_filename)

                result_path = perform_osmnx_analysis(
                    flood_vector_path=st.session_state.flood_file_path,
                    osm_polygons_path=st.session_state.osm_file_path,
                    output_gpkg_path=output_gpkg_path,
                )

                st.session_state.output_statistics_path = result_path

            except Exception as e:
                st.error(f"Ocorreu um erro durante a execução da análise estatística: {e}")
                st.session_state.output_statistics_path = None
            finally:
                # Clean up temporary input files after analysis attempt
                if st.session_state.flood_file_path and os.path.exists(st.session_state.flood_file_path):
                    os.remove(st.session_state.flood_file_path)
                    st.session_state.flood_file_path = None
                    st.session_state.flood_file_hash = None
                if st.session_state.osm_file_path and os.path.exists(st.session_state.osm_file_path):
                    os.remove(st.session_state.osm_file_path)
                    st.session_state.osm_file_path = None
                    st.session_state.osm_file_hash = None
    else:
        st.warning("Por favor, faça upload de ambos os arquivos (vetor de inundação e polígonos OSM) para iniciar a análise.")

# --- Download Button for Results ---
if st.session_state.output_statistics_path and os.path.exists(st.session_state.output_statistics_path):
    st.subheader("Download do Resultado:")
    output_filename = os.path.basename(st.session_state.output_statistics_path)
    with open(st.session_state.output_statistics_path, "rb") as f:
        st.download_button(
            label="Baixar Polígonos OSM Afetados (GeoPackage)",
            data=f.read(),
            file_name=output_filename,
            mime="application/octet-stream"
        )
    st.info(f"O arquivo de resultado foi salvo em: {st.session_state.output_statistics_path}")

# --- Cleanup on app reset/no files uploaded ---
if uploaded_flood_file is None and uploaded_osm_file is None:
    if st.session_state.flood_file_path and os.path.exists(st.session_state.flood_file_path):
        os.remove(st.session_state.flood_file_path)
        st.session_state.flood_file_path = None
        st.session_state.flood_file_hash = None
    if st.session_state.osm_file_path and os.path.exists(st.session_state.osm_file_path):
        os.remove(st.session_state.osm_file_path)
        st.session_state.osm_file_path = None
        st.session_state.osm_file_hash = None
    st.session_state.output_statistics_path = None
