import rasterio
import rasterio.features
import geopandas as gpd
import numpy as np
from shapely.geometry import shape
import warnings
import os

try:
    from pysheds.grid import Grid
except ImportError:
    print("Erro: Biblioteca 'pysheds' não encontrada. Instale com 'pip install pysheds'")
    raise

warnings.filterwarnings("ignore", category=FutureWarning)

def delimit_watershed(input_dem_path, output_dir, outlet_coords, stream_threshold):
    os.makedirs(output_dir, exist_ok=True)
    print(f"Diretório de saída: '{output_dir}'")

    try:
        if not os.path.exists(input_dem_path):
            raise FileNotFoundError(f"Arquivo MDE '{input_dem_path}' não encontrado.")

        print("Carregando MDE e instanciando Grid PySheds...")
        grid = Grid.from_raster(input_dem_path, data_name='dem')
        dem = grid.read_raster(input_dem_path)

        print("Condicionando MDE...")
        pit_filled_dem = grid.fill_pits(dem)
        flooded_dem = grid.fill_depressions(pit_filled_dem)
        inflated_dem = grid.resolve_flats(flooded_dem)

        print("Calculando direção e acumulação do fluxo...")
        dirmap = (64, 128, 1, 2, 4, 8, 16, 32)
        fdir = grid.flowdir(inflated_dem, dirmap=dirmap)
        acc = grid.accumulation(fdir, dirmap=dirmap)

        print(f"Usando exutório em: {outlet_coords}")
        x_outlet, y_outlet = outlet_coords

        streams_mask = acc > stream_threshold

        print("Realizando snap do exutório...")
        try:
            x_snap, y_snap = grid.snap_to_mask(streams_mask, (x_outlet, y_outlet))
        except ValueError as e:
            print(f"Erro ao fazer snap: {e}. Verifique se as coordenadas estão dentro da área do MDE.")
            raise

        print("Delimitando bacia hidrográfica...")
        catch = grid.catchment(x=x_snap, y=y_snap, fdir=fdir, dirmap=dirmap, xytype='coordinate')
        
        grid.clip_to(catch)

        print("Vetorizando a bacia...")
        catch_view = grid.view(catch)
        catchment_shapes = rasterio.features.shapes(
            catch_view.astype(np.uint8),
            mask=catch_view,
            transform=grid.viewfinder.affine
        )
        catchment_geoms = [shape(geom) for geom, value in catchment_shapes if value == 1]
        
        if not catchment_geoms:
            raise RuntimeError("Não foi possível vetorizar a bacia.")

        catchment_gdf = gpd.GeoDataFrame(geometry=catchment_geoms, crs=grid.viewfinder.crs).dissolve()

        bacia_path = os.path.join(output_dir, 'bacia_delimitada.geojson')
        catchment_gdf.to_file(bacia_path, driver='GeoJSON')
        
        print(f"Arquivo da bacia hidrográfica salvo em: '{bacia_path}'")
        return bacia_path

    except Exception as e:
        print(f"Erro inesperado durante a delimitação da bacia: {e}")
        raise
