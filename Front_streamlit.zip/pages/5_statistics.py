import streamlit as st
import geopandas as gpd
import leafmap.foliumap as leafmap

st.set_page_config(layout="wide")

st.title("Análise de Impacto")

# Função para análise de impacto com OpenStreetMap
def calculate_osm_impact(flood_analysis_gdf, osm_polygons_gdf_input):
    """
    Calcula as estatísticas de impacto de uma área de inundação sobre polígonos do OSM.
    """
    try:
        if flood_analysis_gdf.empty:
            st.warning("A camada de inundação está vazia.")
            return None, None, None, None

        if len(flood_analysis_gdf) > 1:
            flood_analysis_gdf['temp_id'] = 1
            flood_analysis_gdf = flood_analysis_gdf.dissolve(by='temp_id')

        target_crs = flood_analysis_gdf.crs if not flood_analysis_gdf.empty and flood_analysis_gdf.crs else osm_polygons_gdf_input.crs

        if osm_polygons_gdf_input.empty:
            osm_polygons_gdf = gpd.GeoDataFrame(geometry=[], crs=target_crs)
        elif osm_polygons_gdf_input.crs != target_crs and target_crs is not None:
            osm_polygons_gdf = osm_polygons_gdf_input.to_crs(target_crs)
        else:
            osm_polygons_gdf = osm_polygons_gdf_input

        if 'natural' in osm_polygons_gdf.columns:
            osm_polygons_gdf = osm_polygons_gdf[osm_polygons_gdf['natural'].fillna('').astype(str).str.lower() != 'water']
        if 'water' in osm_polygons_gdf.columns:
            osm_polygons_gdf = osm_polygons_gdf[osm_polygons_gdf['water'].isna()]

        affected_polygons_gdf = gpd.GeoDataFrame(geometry=[], crs=target_crs if target_crs is not None else 'EPSG:4326')
        if not osm_polygons_gdf.empty and not flood_analysis_gdf.empty:
            if osm_polygons_gdf.crs != flood_analysis_gdf.crs:
                osm_polygons_gdf = osm_polygons_gdf.to_crs(flood_analysis_gdf.crs)

            affected_sjoin = gpd.sjoin(osm_polygons_gdf, flood_analysis_gdf, how='inner', predicate='intersects')
            if not affected_sjoin.empty:
                affected_polygons_gdf = affected_sjoin[~affected_sjoin.index.duplicated(keep='first')]

        total_polygons_aoi = len(osm_polygons_gdf)
        stats_impact_total = len(affected_polygons_gdf)

        stats_impact_buildings = 0
        if 'building' in affected_polygons_gdf.columns:
            stats_impact_buildings = len(affected_polygons_gdf[affected_polygons_gdf['building'].notna() & (affected_polygons_gdf['building'].astype(str).str.lower() != 'no')])

        stats_impact_infra_critica = 0
        if 'amenity' in affected_polygons_gdf.columns:
            critical_amenities = ['hospital', 'school']
            stats_impact_infra_critica = len(affected_polygons_gdf[affected_polygons_gdf['amenity'].isin(critical_amenities)])

        stats_impact_comercio = 0
        if 'shop' in affected_polygons_gdf.columns:
            stats_impact_comercio = len(affected_polygons_gdf[affected_polygons_gdf['shop'].notna()])

        saved_percent_affected = (stats_impact_total / total_polygons_aoi) * 100 if total_polygons_aoi > 0 else 0.0

        stats = {
            "total_polygons_aoi": total_polygons_aoi,
            "impact_total": stats_impact_total,
            "impact_perc_total": round(saved_percent_affected, 2),
            "impact_buildings": stats_impact_buildings,
            "impact_infra_critica": stats_impact_infra_critica,
            "impact_comercio": stats_impact_comercio,
        }

        if not flood_analysis_gdf.empty:
            result_gdf = flood_analysis_gdf.copy()
            first_index = result_gdf.index[0]
            for key, value in stats.items():
                result_gdf.loc[first_index, f'osm_{key}'] = value
            return result_gdf, stats, affected_polygons_gdf, osm_polygons_gdf
        else:
            return None, None, None, None

    except Exception as e:
        st.error(f"Erro ao calcular estatísticas de impacto: {e}")
        return None, None, None, None

# Função para análise genérica
def calculate_generic_impact(analysis_gdf, data_gdf):
    """
    Calcula a interseção entre uma camada de análise e uma camada de dados.
    """
    try:
        if analysis_gdf.empty or data_gdf.empty:
            st.warning("Uma ou ambas as camadas estão vazias.")
            return None, None

        # Dissolve a camada de análise para garantir uma única geometria
        analysis_gdf['temp_id'] = 1
        analysis_gdf = analysis_gdf.dissolve(by='temp_id')

        # Garante que os GDFs tenham o mesmo CRS
        if analysis_gdf.crs != data_gdf.crs:
            data_gdf = data_gdf.to_crs(analysis_gdf.crs)

        # Realiza a interseção espacial
        affected_features = gpd.sjoin(data_gdf, analysis_gdf, how='inner', predicate='intersects')
        
        # Remove duplicatas
        affected_features = affected_features[~affected_features.index.duplicated(keep='first')]

        return len(affected_features), affected_features

    except Exception as e:
        st.error(f"Erro ao calcular o impacto genérico: {e}")
        return None, None

# Função para exibir o mapa do OpenStreetMap
def display_osm_map(gdf_flood, osm_polygons_gdf, affected_polygons_gdf):
    st.header("Visualização do Mapa de Impacto (Dinâmico)")
    m = leafmap.Map()

    style_osm = {'color': '#cccccc', 'weight': 0.5, 'fillOpacity': 0.5, 'fillColor': '#cccccc'}
    style_flood = {'color': 'blue', 'weight': 1, 'fillOpacity': 0.4, 'fillColor': 'blue'}
    style_affected_osm = {'color': 'red', 'weight': 2, 'fillColor': 'red', 'fillOpacity': 0.7}

    if osm_polygons_gdf is not None and not osm_polygons_gdf.empty:
        m.add_gdf(osm_polygons_gdf, layer_name='OSM Polígonos', style=style_osm)

    if not gdf_flood.empty:
        m.add_gdf(gdf_flood, layer_name='Área de Risco', style=style_flood)

    if affected_polygons_gdf is not None and not affected_polygons_gdf.empty:
        m.add_gdf(affected_polygons_gdf, layer_name='Polígonos Afetados', style=style_affected_osm)

    m.to_streamlit(key="map_osm")

# Função para exibir o mapa genérico
def display_generic_map(gdf_analysis, gdf_data, affected_features):
    st.header("Visualização do Mapa")
    m_generic = leafmap.Map()

    style_analysis = {'color': 'yellow', 'fillColor': 'blue', 'weight': 1, 'fillOpacity': 0.4}
    style_data = {'color': 'gray', 'fillColor': '#cccccc', 'weight': 0.5, 'fillOpacity': 0.5}
    style_affected = {'color': 'red', 'weight': 2.5, 'fillColor': 'red', 'fillOpacity': 0.7}

    m_generic.add_gdf(gdf_analysis, layer_name='Camada de Análise', style=style_analysis)
    m_generic.add_gdf(gdf_data, layer_name='Camada de Dados', style=style_data)
    if affected_features is not None and not affected_features.empty:
        m_generic.add_gdf(affected_features, layer_name='Feições Afetadas', style=style_affected)
    
    m_generic.to_streamlit(key="map_generic")

# Abas da aplicação
tab1, tab2 = st.tabs(["Análise com OpenStreetMap", "Análise Genérica"])

with tab1:
    st.markdown(
        """
        Esta análise calcula o impacto de uma mancha de inundação (ou outra área de risco)
        sobre dados de edificações e infraestrutura extraídos do OpenStreetMap (OSM).
        Faça o upload da camada de risco e da camada com os polígonos do OSM.
        """
    )

    col1_osm, col2_osm = st.columns([1, 1])

    with col1_osm:
        st.header("Upload de Camadas")
        flood_layer = st.file_uploader(
            "Carregue a camada de Inundação/Risco (Polígono)",
            type=["geojson", "gpkg", "shp", "zip"],
            key="flood"
        )
        osm_layer = st.file_uploader(
            "Carregue a camada de Polígonos do OSM",
            type=["geojson", "gpkg", "shp", "zip"],
            key="osm"
        )

    if flood_layer and osm_layer:
        try:
            gdf_flood = gpd.read_file(flood_layer)
            gdf_osm_input = gpd.read_file(osm_layer)

            result_gdf, stats, affected_polygons_gdf, osm_polygons_gdf = calculate_osm_impact(gdf_flood, gdf_osm_input)

            if result_gdf is not None and stats is not None:
                with col2_osm:
                    st.header("Estatísticas de Impacto")
                    st.metric("Total de polígonos OSM na área", f"{stats['total_polygons_aoi']:,}")
                    st.metric("Total de polígonos OSM afetados", f"{stats['impact_total']:,}")
                    st.metric("Percentual de polígonos afetados", f"{stats['impact_perc_total']:.2f}%")
                    st.metric("Edificações afetadas", f"{stats['impact_buildings']:,}")
                    st.metric("Infraestrutura crítica afetada (escola/hospital)", f"{stats['impact_infra_critica']:,}")
                    st.metric("Comércio afetado", f"{stats['impact_comercio']:,}")

                    output_geojson_osm = result_gdf.to_json()
                    st.download_button(
                        label="Baixar resultado com estatísticas (impact_stats.geojson)",
                        data=output_geojson_osm,
                        file_name="impact_stats.geojson",
                        mime="application/json",
                    )

                display_osm_map(gdf_flood, osm_polygons_gdf, affected_polygons_gdf)

        except Exception as e:
            st.error(f"Ocorreu um erro ao processar os arquivos: {e}")
    else:
        with col2_osm:
            st.info("Aguardando o upload das duas camadas para iniciar a análise de impacto.")

with tab2:
    st.markdown(
        """
        Esta análise genérica calcula a quantidade de feições de uma camada de dados
        que estão dentro de uma camada de análise. Faça o upload das duas camadas.
        """
    )
    
    col1_generic, col2_generic = st.columns([1, 1])

    with col1_generic:
        st.header("Upload de Camadas")
        analysis_layer = st.file_uploader(
            "Carregue a camada de Análise (Polígono)",
            type=["geojson", "gpkg", "shp", "zip"],
            key="analysis"
        )
        data_layer = st.file_uploader(
            "Carregue a camada de Dados",
            type=["geojson", "gpkg", "shp", "zip"],
            key="data"
        )

    if analysis_layer and data_layer:
        try:
            gdf_analysis = gpd.read_file(analysis_layer)
            gdf_data = gpd.read_file(data_layer)

            affected_count, affected_features = calculate_generic_impact(gdf_analysis, gdf_data)

            if affected_count is not None:
                with col2_generic:
                    st.header("Resultados da Análise")
                    st.metric("Total de feições na camada de dados", f"{len(gdf_data):,}")
                    st.metric("Feições afetadas pela camada de análise", f"{affected_count:,}")

                display_generic_map(gdf_analysis, gdf_data, affected_features)

        except Exception as e:
            st.error(f"Ocorreu um erro ao processar os arquivos: {e}")
    else:
        with col2_generic:
            st.info("Aguardando o upload das duas camadas para iniciar a análise.")
