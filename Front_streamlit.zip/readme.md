# Análise Hidrográfica Integrada e Análise de Impacto

## Descrição

Esta aplicação é uma ferramenta de geoprocessamento baseada na web, construída com Streamlit, projetada para realizar análises hidrográficas e de impacto. Ela permite aos usuários baixar dados geoespaciais do Google Earth Engine e, em seguida, usar esses dados para avaliar o impacto de áreas de risco (como inundações) em feições geográficas, como edificações e infraestrutura, extraídas do OpenStreetMap ou de outras fontes de dados vetoriais.

O principal objetivo do projeto é fornecer uma interface amigável para que analistas e planejadores possam rapidamente visualizar e quantificar os efeitos de um evento em uma determinada área de interesse.

## Principais Funcionalidades

-   **Downloader de Dados Geoespaciais**: Baixa dados de sensoriamento remoto e geoprocessamento diretamente do Google Earth Engine.
-   **Análise de Impacto com OpenStreetMap**: Calcula o impacto de uma mancha de inundação ou outra área de risco sobre edificações, infraestrutura crítica (hospitais, escolas) e comércio mapeados no OpenStreetMap.
-   **Análise de Impacto Genérica**: Realiza uma análise de interseção espacial entre duas camadas vetoriais quaisquer fornecidas pelo usuário.
-   **Visualização Interativa**: Exibe os resultados da análise em um mapa interativo, destacando as áreas de risco e as feições afetadas.
-   **Suporte a Múltiplos Formatos**: Permite o upload de dados em formatos populares como GeoJSON, GPKG e Shapefile (em um arquivo .zip).
-   **Exportação de Resultados**: Gera um arquivo GeoJSON com as estatísticas de impacto agregadas à geometria da área de análise.

## Pré-requisitos

Para executar este projeto, você precisará ter o Python instalado, bem como as seguintes bibliotecas. Recomenda-se o uso de um ambiente virtual.

-   streamlit
-   geopandas
-   earthengine-api
-   geemap
-   requests
-   pysheds
-   osmnx
-   rasterio
-   numpy
-   shapely
-   pyproj

## Instalação

1.  Clone o repositório para sua máquina local.
2.  Navegue até o diretório do projeto.
3.  Crie e ative um ambiente virtual (recomendado):
    