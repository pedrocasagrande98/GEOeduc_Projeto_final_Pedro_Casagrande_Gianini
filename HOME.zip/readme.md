# 🛰️ Plataforma de Análise Geoespacial Integrada 🌎

## Descrição

Esta plataforma é uma aplicação web de análise geoespacial que integra diversas ferramentas de geoprocessamento e sensoriamento remoto. O objetivo principal é fornecer uma interface amigável para realizar análises hidrológicas, de risco e de impacto, utilizando dados de fontes como Google Earth Engine (GEE), OpenStreetMap (OSM) e Google Open Buildings. O projeto resolve a necessidade de uma ferramenta unificada para processar e analisar dados geoespaciais de múltiplas fontes, automatizando tarefas complexas e permitindo que usuários, mesmo sem profundo conhecimento em programação, possam realizar análises robustas.

## Principais Funcionalidades

*   **Downloader de Dados (GEE)**: Baixa dados de Modelo Digital de Elevação (MDE), incluindo elevação, declividade e aspecto, além de dados de água disponível no solo e cobertura do solo (Mapbiomas) para uma área de interesse (AOI) definida pelo usuário.
*   **Análise Hidrológica**: Realiza o pré-processamento de MDEs, delimita bacias hidrográficas e calcula o mapa de Altura Acima do Canal mais Próximo (HAND), um importante indicador para análise de inundações.
*   **Modelo de Risco Ponderado por Solo**: Aplica um modelo de risco que ajusta as áreas de inundação com base nas diferentes classes de solo, aplicando buffers proporcionais para refinar a análise de risco.
*   **Downloader de Dados (OSM)**: Permite o download de dados vetoriais do OpenStreetMap, como arruamento, construções, e outras feições de infraestrutura para a AOI.
*   **Downloader de Dados (Open Buildings)**: Facilita o download de polígonos de construções a partir do projeto Google Open Buildings.
*   **Análise Quantitativa**: Calcula estatísticas de impacto, como a contagem e a porcentagem de feições (ex: construções) que são interceptadas por uma camada de análise (ex: mancha de inundação).

## Pré-requisitos

As seguintes bibliotecas são necessárias para executar o projeto:

*   earthengine-api
*   geemap
*   geopandas
*   numpy
*   osmnx
*   pandas
*   pyproj
*   pysheds
*   rasterio
*   requests
*   s2sphere
*   shapely
*   streamlit
*   tqdm

## Instalação

1.  **Clone o repositório:**
    ```bash
    git clone <URL_DO_REPOSITORIO>
    cd <NOME_DO_DIRETORIO>
    ```

2.  **Crie e ative um ambiente virtual (recomendado):**
    ```bash
    python -m venv venv
    source venv/bin/activate  # No Windows, use `venv\Scripts\activate`
    ```

3.  **Instale as dependências:**
    ```bash
    pip install -r requirements.txt
    ```

## Como Usar

1.  **Execute a aplicação Streamlit:**
    ```bash
    streamlit run HOME.py
    ```

2.  **Acesse a aplicação no seu navegador:**
    Abra o endereço `http://localhost:8501` no seu navegador.

3.  **Navegue e utilize as funcionalidades:**
    *   Use o menu na barra lateral para selecionar a análise desejada.
    *   Siga as instruções em cada página para fazer o upload dos seus dados (GeoJSON, Shapefile, etc.) ou definir sua área de interesse.
    *   Ajuste os parâmetros conforme necessário e inicie o processamento.
    *   Visualize e baixe os resultados diretamente na interface.

## Estrutura do Projeto

```
.
├── HOME.py                # Script principal da aplicação Streamlit (página inicial)
├── pages/                 # Diretório contendo os scripts de cada página/análise
│   ├── 1_Downloader_GEE.py
│   ├── 2_Análise_Hidrológica.py
│   ├── 3_Modelo_Risco.py
│   ├── 4_Downloader_OSM.py
│   ├── 5_Downloader_Open_Buildings.py
│   └── 6_Análise_Quantitativa.py
├── requirements.txt       # Lista de dependências Python
├── scripts/               # Módulos com a lógica de processamento principal
│   └── ...
└── cache/                 # Diretório para armazenamento de dados em cache
```