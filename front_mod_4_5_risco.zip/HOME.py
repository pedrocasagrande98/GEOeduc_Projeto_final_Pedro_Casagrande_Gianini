### =-=-=-=-= não apagar streamlit run HOME.py =-=-=-=- ##
import streamlit as st

st.set_page_config(
    page_title="Análise Hidrográfica Integrada",
    page_icon="🛰️", # Alterei para um ícone mais genérico
    layout="wide"
)

st.title("🛰️ Downloader de Dados Geoespaciais 🌎")
st.markdown("---")
st.markdown("Bem-vindo ao Downloader de Dados Geoespaciais! Esta aplicação utiliza o Google Earth Engine para buscar e baixar dados de sensoriamento remoto e geoprocessamento.")
st.markdown("### Como usar:")
st.info("""
1.  **Navegue para a página 'Download de Dados' no menu lateral.**
2.  **Siga as instruções para inserir seu User ID do GEE e fazer upload de uma área de interesse (GPKG/GeoJSON).**
3.  **Selecione o dado, configure os parâmetros e escolha a forma de obtenção (Download ou Google Drive).**
4.  **Explore o resultado no mapa interativo.**
""")
st.markdown("---")
st.image("https://i.imgur.com/rztB5pr.png", caption="Visualização da Bacia Hidrográfica e Rede de Drenagem")

st.markdown("""
    <style>
    html, body, [class*="st-"] {
        font-size: 1.1rem;
    }
    </style>
""", unsafe_allow_html=True)